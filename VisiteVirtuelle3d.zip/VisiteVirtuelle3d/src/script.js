import './style.css'
import * as THREE from 'three'
import { PointerLockControls } from 'three/examples/jsm/controls/PointerLockControls'
import Stats from 'three/examples/jsm/libs/stats.module'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'

import * as dat from 'dat.gui'
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js'
import {gsap} from 'gsap'
import screenfull from 'screenfull';
import { AxesHelper } from 'three'

/* if (screenfull.isEnabled) {
	screenfull.request();
} */


/// INITIALISATION


let lumiereAmbiante;
var objects = [];
var intersects = [];
var collisions = [];
var murs

let raycaster;

let moveForward = false;
let moveBackward = false;
let moveLeft = false;
let moveRight = false;
let canJump = false;
var characterSize = 10;


let prevTime = performance.now();
const velocity = new THREE.Vector3();
const direction = new THREE.Vector3();
const vertex = new THREE.Vector3();
const color = new THREE.Color();

init();

function init(){
document.querySelector("img").setAttribute("src", "7.jpg")
document.querySelector("img").setAttribute("src", "6.jpg")




/* 
Loaders */
 const loadingBarElement = document.querySelector('.loading-bar')
 const progressBar = document.querySelector('.progressbar')
 const patientez = document.querySelector('.patientez')


const loadingManager = new THREE.LoadingManager(
  //loaded
  () =>
  {
      gsap.delayedCall(0.5, () =>
        {
          gsap.to(overlayMaterial.uniforms.uAlpha, {duration: 3, value: 0})
          loadingBarElement.classList.add('ended')
          loadingBarElement.style.transform = ''
          progressBar.style.display = 'none'
          patientez.style.display = 'none'

        })
      
  },
  // progress
  (itemUrl, itemsLoaded, itemsTotal) =>{
    //let progressRatio = Math.round(100 * itemsLoaded / itemsTotal)
    const progressRatio =  itemsLoaded / itemsTotal
    loadingBarElement.style.transform = `scaleX(${progressRatio})`
    //loadingBarElement.style.width = `${progressRatio}%`
    
  }
) 


 const gltfLoader = new GLTFLoader(loadingManager)
 const cubeTextureLoader = new THREE.CubeTextureLoader(loadingManager)
  

/**
* Base
*/

//const gui = new dat.GUI()
const debugObject = {}


const canvas = document.querySelector('canvas.webgl')

const scene = new THREE.Scene()


/* var rotationPoint = new THREE.Object3D();
rotationPoint.position.set( 0, 0, 0 );
scene.add( rotationPoint );

 */

//Overlay

const overlayGeometry = new THREE.PlaneBufferGeometry(2, 2, 1, 1)
const overlayMaterial = new THREE.ShaderMaterial({
     transparent: true,
     uniforms : {
       uAlpha: {value: 1}
     },
    vertexShader: `
    void main()
    {
      gl_Position =  vec4(position, 1.0);
    }
  `,
  fragmentShader: `
  uniform float uAlpha;
    void main(){
      gl_FragColor = vec4(0.0, 0.0, 0.0, uAlpha);
    }
  `
})
const overlay = new THREE.Mesh(overlayGeometry, overlayMaterial)
scene.add(overlay)


const sizes = {
    width: window.innerWidth,
    height: window.innerHeight
}

//const camera = new THREE.PerspectiveCamera(75, sizes.width / sizes.height, 1, 2000)
//camera.position.set(10, 1, - 10)



const lumiereAmbiante = new THREE.AmbientLight( 0x404040, 3 );
scene.add( lumiereAmbiante );
 /* gui
.add(lumiereAmbiante, 'intensity')
.min(0).max(10).step(0.001)
.name('LightIntensity')  */


/* const controlsorbit = new OrbitControls(camera, canvas)

controlsorbit.enableDamping = true
//controlsorbit.maxDistance = 15

console.log(controlsorbit) */

/* Update All Material */
const updateAllMaterial = () =>
{
    scene.traverse((child) =>
    {
        if(child instanceof THREE.Mesh && child.material instanceof THREE.MeshStandardMaterial)
        {
            child.material.envMapIntensity = debugObject.envMapIntensity
            child.material.needsUpdate = true
        }
        
    }) 
}

/* 
Environment Map */
const environmentMap = cubeTextureLoader.load([
    'textures/environmentMaps/0/px.jpg',
    'textures/environmentMaps/0/nx.jpg',
    'textures/environmentMaps/0/py.jpg',
    'textures/environmentMaps/0/ny.jpg',
    'textures/environmentMaps/0/pz.jpg',
    'textures/environmentMaps/0/nz.jpg',
])
environmentMap.encoding = THREE.sRGBEncoding
scene.background = environmentMap
scene.environment = environmentMap

debugObject.envMapIntensity = 5
//gui.add(debugObject, 'envMapIntensity').min(0).max(10).step(0.001).onChange(updateAllMaterial)

/* Models */
gltfLoader.load(
    '/models/Projet_Cynthia20.gltf',
    (gltf) =>
    { 
        gltf.scene.scale.set(20, 20, 20)
        gltf.scene.position.set (-10, -15, 30)
        gltf.scene.rotation.y = 0.319
        scene.add(gltf.scene)
        murs = gltf.scene.getObjectByName('Room');
        const lampe1 = gltf.scene.getObjectByName('lampe1dsupport');
        const lampe2 = gltf.scene.getObjectByName('lampe2dsupport');
        const murblanc = gltf.scene.getObjectByName('Mure_blanc');
        const porte1 = gltf.scene.getObjectByName('porte1');
        const porte2 = gltf.scene.getObjectByName('porte2');
        const porte3 = gltf.scene.getObjectByName('porte3');
        const porte4 = gltf.scene.getObjectByName('porte4');
        const lampe1d1 = gltf.scene.getObjectByName('lampe1d1');
        const lampe1d2 = gltf.scene.getObjectByName('lampe1d2');
        const lampe2d1 = gltf.scene.getObjectByName('lampe2d1');
        const lampe2d2 = gltf.scene.getObjectByName('lampe2d2');
        const oratoire = gltf.scene.getObjectByName('Horatoire');



        objects[0] = murs
        objects[1] = lampe1
        objects[2] = lampe2
        objects[3] = murblanc
        objects[4] = porte1
        objects[5] = porte2
        objects[6] = porte3
        objects[7] = porte4
        objects[10] = lampe1d1
        objects[11] = lampe1d2
        objects[12] = lampe2d1
        objects[13] = lampe2d2
        objects[14] = oratoire


        const murBB = new THREE.Box3(new THREE.Vector3(), new THREE.Vector3())
        //murBB.setFromObject(murs)
        //console.log(murBB)
        console.log(objects)
        //charge()

       /*  gui
        .add(gltf.scene.rotation, 'y')
        .min(- Math.PI)
        .max(Math.PI)
        .step(0.001)
        .name('rotation') */

        updateAllMaterial()
        //console.log(gltf)

        
    
    }
)
/* console.log(murs)
console.log(murBB)
console.log(objects[0])

function charge() {} */

/* const axesHelper = new THREE.AxesHelper( 5 );
axesHelper.scale.set(10, 10, 10)
axesHelper.position.set(3, 2,10)
axesHelper.rotation.y = 0.319

scene.add( axesHelper ); */
//scene.add( controls.getObject() );
const camera1 = new THREE.PerspectiveCamera(75, sizes.width / sizes.height, 1, 2000)

//scene.add(camera1)

var geometry = new THREE.BoxGeometry(5, 5, 5 );
var material = new THREE.MeshPhongMaterial({ color: 0x22dd88 });
var cible = new THREE.Mesh( geometry, material );
cible.position.y =10;
cible.position.z = -10;

let cibleBB = new THREE.Box3(new THREE.Vector3(), new THREE.Vector3())
cibleBB.setFromObject(cible)
//console.log(cibleBB)


const geometry1 = new THREE.PlaneGeometry( 1, 1 );
const material1 = new THREE.MeshBasicMaterial( {color: 0xffff00, side: THREE.DoubleSide} );
const plane = new THREE.Mesh( geometry1, material1 );
plane.position.set(35, 14, 14)
plane.scale.set(30, 15)
plane.rotation.y = 0.319
plane.visible = false

scene.add( plane );
objects[8] = plane

const geometry2 = new THREE.PlaneGeometry( 1, 1 );
const material2 = new THREE.MeshBasicMaterial( {color: 0xffff0f, side: THREE.DoubleSide} );
const plane1 = new THREE.Mesh( geometry2, material2 );
plane1.position.set(-50, 14, 40)
plane1.scale.set(30, 15)
plane1.rotation.y = 0.319
plane1.visible = false

scene.add( plane1 );
objects[9] = plane1

//scene.add(cible)
//rotationPoint.add( box );
//camera1.add(cible)


//camera1.position.set(10, 1, - 10)

const controls = new PointerLockControls( camera1, canvas );

//controls.isLocked = false


//const blocker = document.getElementById( 'blocker' );
const instructions = document.getElementById( 'instructions' );
//const ecran = document.getElementById('blocker');

instructions.addEventListener( 'click', function () {

   controls.lock();

} );

 controls.addEventListener( 'lock', function () {

    instructions.style.display = 'none';
    blocker.style.display = 'none';
 
} );

controls.addEventListener( 'unlock', function () {

    blocker.style.display = 'block';
    instructions.style.display = '';

} );




scene.add( controls.getObject() );



const onKeyDown = function ( event ) {

    switch ( event.code ) {

        case 'ArrowUp':
        case 'KeyW':
            moveForward = true;
            break;

        case 'ArrowLeft':
        case 'KeyA':
            moveLeft = true;
            break;

        case 'ArrowDown':
        case 'KeyS':
            moveBackward = true;
            break;

         case 'ArrowRight':
        case 'KeyD':
            moveRight = true;
            break;

        

    }

};

const onKeyUp = function ( event ) {

    switch ( event.code ) {

        case 'ArrowUp':
        case 'KeyW':
            moveForward = false;
            break;

        case 'ArrowLeft':
        case 'KeyA':
            moveLeft = false;
            break;

        case 'ArrowDown':
        case 'KeyS':
            moveBackward = false;
            break;

        case 'ArrowRight':
        case 'KeyD':
            moveRight = false;
            break;

    }

};

document.addEventListener( 'keydown', onKeyDown );
document.addEventListener( 'keyup', onKeyUp );

window.addEventListener('resize', () =>
{
    sizes.width = window.innerWidth
    sizes.height = window.innerHeight

    //camera.aspect = sizes.width / sizes.height
    //camera.updateProjectionMatrix() 

    camera1.aspect = sizes.width / sizes.height
    camera1.updateProjectionMatrix()

    renderer.setSize(sizes.width, sizes.height)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    
})


/**
 * Renderer
 */
 const renderer = new THREE.WebGLRenderer({
    canvas: canvas,
    antialias: true
})
renderer.setSize(sizes.width, sizes.height)
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
renderer.physicallyCorrectLights = true
renderer.outputEncoding = THREE.sRGBEncoding
renderer.toneMapping = THREE.ACESFilmicToneMapping
renderer.toneMappingExposure = 2

    /* gui
        .add(renderer, 'toneMapping', {
            No: THREE.NoToneMapping,
            Linear: THREE.LinearToneMapping,
            Reinhard: THREE.ReinhardToneMapping,
            Cineon: THREE.CineonToneMapping,
            ACESFilmic: THREE.ReinhardToneMapping
    }) */
    /* .onFinishChange(() =>
    {
        renderer.toneMapping = Number(renderer.toneMapping)
        updateAllMaterial()
    }) */
/*  gui.add(renderer, 'toneMappingExposure').min(0).max(10).step(0.001)
 */ 

//raycaster = new THREE.Raycaster( new THREE.Vector3(), new THREE.Vector3( 0, - 1, 0 ), 0, 10 );
//raycaster = new THREE.Raycaster()

    /* const raycaster2 = new THREE.Raycaster()
    const raycaster2Origin = new THREE.Vector3(cible.position)
    const raycaster2ODirection = new THREE.Vector3(-cible.position.x)
    raycaster2ODirection.normalize()
    raycaster2.set(raycaster2Origin, raycaster2ODirection)
    const intersects = raycaster2.intersectObjects( objects, false );
    console.log(raycaster2Origin)
    console.log(raycaster2ODirection)
    console.log( intersects[0])  */

const tick = () =>
{
  //cibleBB.copy(cible.geometry.boundingBox).applyMatrix4(cible.matrixWorld)
  //console.log(cibleBB)
  //checkColisions()
  
  //cible.position.x = camera1.position.x -5
  //cible.position.z = -5
 // console.log(cible.position.x)
  //console.log(camera1.position.x)


 // camera1.updateMatrixWorld(true)

  raycaster = new THREE.Raycaster()

    //detectCollisions()
    // Update controls
    //controlsorbit.update()

    // Render
   // renderer.render(scene, camera)
    renderer.render(scene, camera1)
  //  detectCollision()


    // Call tick again on the next frame
    window.requestAnimationFrame(tick)

    const time = performance.now();
//detectCollision()
 
    


   // const target = new THREE.Vector3()

    // raycaster = new THREE.Raycaster( new THREE.Vector3(), new THREE.Vector3( 0, - 1, 0 ), 0, 10 );
    //raycaster.set(controls.getObject(), target.subVectors(camera1.position, controls.getObject().position).normalize())

    //target.add(camera1)
    //console.log(controls.target)


        raycaster.ray.origin.copy( controls.getObject().position );
      // raycaster.ray.origin.y -= 10;
       // raycaster.setFromCamera(onKeyDown, camera1)

        if ( controls.isLocked === true  ) {
          controls.getObject().position.y = 8

            raycaster.ray.origin.copy( controls.getObject().position );
            //raycaster.ray.origin.y -= 10;

            const intersections = raycaster.intersectObjects( objects, false );
            //console.log(intersections[0].distance)
            //if(intersections){     console.log('intersections')}
            
           // console.log( camera1.position.distance) 
           //console.log( controls.getObject().position)
           var camdirection = new THREE.Vector3 
               camera1.getWorldDirection(camdirection)
              //console.log(camdirection) 
              //console.log(camera1.rotation)
              if(intersections.length > 0) {
                
                //console.log(intersections[0].distance)
                

              /*  if(intersections[0].distance < controls.getObject().position.distanceTo(camera1.position)) 
            {
              console.log('yes!')

             // moveBackward = false
            }   */
           // console.log(controls.getObject().position)
           /* if(intersections[0].distance < 9)
           { */
            for(let i = 0; i < intersections.length; i++){
              if(intersections[i].distance < 10) 
              {
                //console.log(controls.getObject().position)
  
                //console.log(cible.position)
               //console.log(intersections[0].point)
        
                console.log('yes!')
                console.log(intersections[i].distance)
               
                controls.moveForward(-5)
                /* if( cible.position.x < intersections[0].point.x) {
                  console.log('okkkk!')
                  controls.moveForward(10) &&
                  controls.moveForward(-15)
  
                  console.log('super!')
                  console.log(cible.position.x)
                  console.log(intersections[0].point.x)
                //}
               } */
               
  
  
                
               // console.log(intersections[0].distance)
  
                //camera1.position.copy(¢)
                /* controls.getObject().translateZ(10)
               
                controls.getObject().position.x = ¢.x;
                controls.getObject().position.z = intersections[0].point.z + 10.0;
                controls.getObject().position.y = 10
   */
  
  
  
                
  
                console.log(intersections[0].point)
                console.log(-controls.getObject().position.x)
                console.log(cible.position)
  
              
                
                 
               // moveBackward = false
              } 
            }
            
             
            }  
             
           

             const delta = ( time - prevTime ) / 1000;

            velocity.x -= velocity.x * 20.0 * delta;
            velocity.z -= velocity.z * 20.0 * delta;

           // velocity.y -= 9.8 * 100.0 * delta; // 100.0 = mass

            direction.z = Number( moveForward ) - Number( moveBackward );
            direction.x = Number( moveRight ) - Number( moveLeft );
            direction.normalize(); // this ensures consistent movements in all directions

            if ( moveForward || moveBackward ) velocity.z -= direction.z * 400.0 * delta;
            if ( moveLeft || moveRight ) velocity.x -= direction.x * 400.0 * delta;
            

            if ( intersections.length > 0 ) {

                //velocity.y = Math.max( 0, velocity.y );
               // console.log(controls.getObject().position)

              //  canJump = true;
              //console.log(controls.getObject(camera1))
            }

            controls.moveRight( - velocity.x * delta );
            controls.moveForward( - velocity.z * delta );

           // controls.getObject().position.y += ( velocity.y * delta ); // new behavior

            if ( controls.getObject().position.y < 10 ) {

                //velocity.y = 0;
                controls.getObject().position.y = 10;

               // canJump = true;

            } 
            //console.log(camera1.position)


        }

    

    prevTime = time;

    


        
      //renderer.render( scene, camera );
    renderer.render(scene, camera1)

}
function checkColisions() {
  if(cibleBB.intersectsBox(murBB)){
    controls.moveForward(10)
  }
}
tick();
}





 /* document.fullscreenEnabled =
	document.fullscreenEnabled ||
	document.mozFullScreenEnabled ||
	document.documentElement.webkitRequestFullScreen;

function requestFullscreen(element) {
	if (element.requestFullscreen) {
		element.requestFullscreen();
	} else if (element.mozRequestFullScreen) {
		element.mozRequestFullScreen();
	} else if (element.webkitRequestFullScreen) {
		element.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
	}
}

if (document.fullscreenEnabled) {
	requestFullscreen(document.documentElement);
} 

//import screenfull from 'screenfull';

const element = document.getElementById('plein');

document.getElementById('plein').addEventListener('click', () => {
	if (screenfull.isEnabled) {
		screenfull.request(element);
	}
}); */



   /*   var elem = document.getElementById('plein');
//document.fullscreenEnabled = true;
    if (elem.requestFullscreen){
        elem.requestFullscreen();
    }
    document.addEventListener('click', function(){
        toggleFullScreen();
    }, false );
    function toggleFullScreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen();
        } else {
          if (document.exitFullscreen) {
            document.exitFullscreen();
          }
        }
      } 
 */


































