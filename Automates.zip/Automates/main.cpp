//Cynthia AYETOLOU

#include <QCoreApplication>
#include<vector>
using namespace  std;
#include<automaton.h>

// Fonction vecMen(vector<int> v, int n)
// Cette fonction vérifie si un élément donné n existe dans un vecteur d'entiers v
bool vecMen(vector<int> v, int n) {
    for (int i : v) { // Parcourt chaque élément i du vecteur v
        if (i == n) { // Si l'élément i est égal à n
            return true; // Retourne true immédiatement
        }
    }
    return false; // Si aucun élément du vecteur n'est égal à n, retourne false
}

// Fonction vecMen(vector<int> v1, vector<int> v2)
// Cette fonction retourne un vecteur contenant l'intersection des deux vecteurs v1 et v2
vector<int> vecMen(vector<int> v1, vector<int> v2) {
    std::vector<int> intersection; // Initialise un vecteur pour stocker les éléments communs

    for (int nombre : v1) { // Parcourt chaque élément nombre du vecteur v1
        if (vecMen(v2, nombre)) { // Vérifie si nombre existe dans le vecteur v2
            intersection.push_back(nombre); // Si oui, ajoute nombre au vecteur intersection
        }
    }
    return intersection; // Retourne le vecteur contenant les éléments communs
}


// Fonction successors() pour obtenir l'ensemble des états atteignables depuis un ensemble de sources avec une lettre donnée
// Cette fonction retourne les états accessibles à partir de `sources` en suivant les transitions définies par `lettre` dans l'automate `aut`
IdxSet<int> successors(Automaton aut, IdxSet<int> sources, char lettre) {
    IdxSet<int> destinations; // Initialise un ensemble pour stocker les états accessibles

    for (int etat : sources) { // Parcourt chaque état dans l'ensemble des sources
        // Obtenir les états accessibles depuis l'état courant avec la lettre donnée
        IdxSet<int> out = aut.out_states(etat, lettre);

        // Ajouter les états accessibles à l'ensemble destinations
        destinations.add(out);

        //J'affichais pour le debogage pour etre sure que ma fonction successors travaille
        // std::cout << "successors: Transition depuis " << etat << " avec " << lettre << " -> " << out << std::endl;
    }

    return destinations; // Retourne l'ensemble des états accessibles
}



// Cette version de successors traite une séquence de transitions définie par un mot (string).
// Elle calcule les états accessibles après avoir suivi chaque lettre du mot en ordre.

IdxSet<int> successors(Automaton aut, IdxSet<int> sources, string mots) {
    IdxSet<int> resultat; // Initialise un ensemble pour stocker les états atteints

    resultat = sources; // Commence avec l'ensemble des états sources initiaux

    // Parcourt chaque lettre du mot
    for (char lettre : mots) {
        // Calcule les états accessibles après une transition avec la lettre actuelle
        resultat = successors(aut, resultat, lettre);
    }

    return resultat; // Retourne l'ensemble final des états accessibles après avoir suivi tout le mot
}



// Fonction appartient() pour vérifier si un mot est accepté par un automate
// Cette fonction retourne true si le mot mène à un état final, sinon false

bool appartient(Automaton aut, string mot) {
    IdxSet<int> sortie; // Initialise un ensemble pour stocker les états accessibles après lecture du mot

    // Étape 1 : Calculer les états atteints après avoir suivi les transitions du mot
    sortie = successors(aut, aut.get_inits(), mot); // États accessibles à partir des états initiaux après lecture du mot

    // Étape 2 : Vérifier si l'un des états atteints est un état final
    for (int etat : sortie) { // Parcourt chaque état dans l'ensemble des états atteints
        if (aut.is_final(etat)) { // Si un des états accessibles est un état final
            return true; // Le mot est accepté par l'automate
        }
    }

    return false; // Si aucun état final n'est atteint, le mot est rejeté
}



// Fonction successorsstart() pour calculer tous les états accessibles à partir d'un ensemble d'états sources
// Cette fonction explore toutes les transitions possibles à partir des états initiaux jusqu'à ce qu'aucun nouvel état ne soit atteignable
IdxSet<int> successorsstart(Automaton aut, IdxSet<int> srcs) {
    IdxSet<int> reachables = srcs; // Initialise l'ensemble des états accessibles avec les états sources initiaux
    IdxSet<int> toBeTreated = srcs; // Initialise la file des états à traiter avec les mêmes états sources

    // Ajoute les états initiaux à l'ensemble des accessibles (déjà fait par srcs, peut être redondant)
    reachables.add(srcs);

    // Tant qu'il reste des états à explorer
    while (!toBeTreated.is_empty()) {
        int q = toBeTreated.choose(); // Sélectionne un état à traiter dans la file

        // Parcourt chaque symbole de l'alphabet de l'automate
        for (char a : aut.get_alphabet()) {
            // Parcourt chaque état atteignable à partir de q avec le symbole a
            for (int s : aut.out_states(q, a)) {
                if (!reachables.mem(s)) { // Si l'état s n'a pas encore été ajouté aux accessibles
                    reachables.add(s); // Ajoute s à l'ensemble des états accessibles
                    toBeTreated.add(s); // Ajoute s à la file des états à traiter
                }
            }
        }
    }

    return reachables; // Retourne l'ensemble des états accessibles
}



// Fonction emptyLanguage() pour vérifier si le langage reconnu par un automate est vide
// Cette fonction détermine si l'automate n'accepte aucun mot (langage vide)
bool emptyLanguage(Automaton aut) {
    // Récupère l'ensemble des états initiaux de l'automate
    IdxSet<int> initialStates = aut.get_inits();

    // Calcule l'ensemble des états atteignables à partir des états initiaux
    IdxSet<int> reachableStates = successorsstart(aut, initialStates);

    // Parcourt tous les états atteignables
    for (int state : reachableStates) {
        // Vérifie si l'un des états atteignables est un état final
        if (aut.is_final(state)) {
            // Si un état final est accessible, le langage n'est pas vide
            return false;
        }
    }

    // Si aucun état final n'est accessible, le langage de l'automate est vide
    return true;
}



// methode trim() pour réduire un automate en supprimant les états inutiles
// Un état est utile s'il est à la fois accessible depuis un état initial et coaccessible (peut atteindre un état final)

Automaton trim(Automaton aut) {
    // Étape 1 : Calculer les états accessibles depuis les états initiaux
    // Les états accessibles sont ceux que l'on peut atteindre à partir des états initiaux en suivant les transitions de l'automate
    IdxSet<int> reachable = successorsstart(aut, aut.get_inits());
    // (Optionnel) std::cout << "trim: États accessibles : " << reachable << std::endl;

    // Étape 2 : Calculer les états coaccessibles (qui peuvent atteindre un état final)
    IdxSet<int> coaccessible; // Ensemble pour stocker les états coaccessibles

    // Ajouter directement les états finaux à l'ensemble des états coaccessibles
    for (int state : aut) { // Parcourt tous les états de l'automate
        if (aut.is_final(state)) {
            coaccessible.add(state); // Un état final est par définition coaccessible
        }
    }

    // Identifier les prédécesseurs des états coaccessibles
    for (int state : aut) { // Parcourt tous les états de l'automate
        for (char c : aut.get_alphabet()) { // Pour chaque lettre de l'alphabet
            IdxSet<int> preds = aut.in_states(c, state); // Trouve les états qui mènent à `state` avec la lettre `c`
            coaccessible.add(preds); // Ajoute les prédécesseurs à l'ensemble des états coaccessibles
        }
    }
    // (Optionnel) std::cout << "trim: États coaccessibles : " << coaccessible << std::endl;

    // Étape 3 : Construire l'automate réduit en ne gardant que les états à la fois accessibles et coaccessibles
    Automaton result; // Automate réduit
    std::map<int, int> stateMap; // Associe les anciens états aux nouveaux indices dans l'automate réduit

    IdxSet<int> initialStates = aut.get_inits(); // Récupère les états initiaux de l'automate original

    // Ajouter les états accessibles et coaccessibles
    for (int state : reachable) { // Parcourt les états accessibles
        if (coaccessible.mem(state)) { // Si l'état est également coaccessible
            int newState = result.newstate(); // Crée un nouvel état dans l'automate réduit
            stateMap[state] = newState; // Mappe l'ancien état au nouvel état
            if (initialStates.mem(state)) result.add_init(newState); // Si l'état était initial, l'ajoute comme état initial
            if (aut.is_final(state)) result.add_final(newState); // Si l'état était final, l'ajoute comme état final
        }
    }

    // Ajouter les transitions pour les états restants dans l'automate réduit
    for (int state : reachable) { // Parcourt les états accessibles
        if (coaccessible.mem(state)) { // Si l'état est également coaccessible
            for (char c : aut.get_alphabet()) { // Pour chaque lettre de l'alphabet
                for (int target : aut.out_states(state, c)) { // Parcourt les états atteignables avec cette lettre
                    if (coaccessible.mem(target) && stateMap.count(target)) { // Vérifie que la cible est dans le nouvel automate
                        result.add_trans(stateMap[state], c, stateMap[target]); // Ajoute la transition dans l'automate réduit
                    }
                }
            }
        }
    }

    return result; // Retourne l'automate réduit
}



// Fonction pour donner l'automate reconnaissant l'intersection des langages de deux automates
// L'automate résultant reconnaît uniquement les mots acceptés à la fois par aut1 et aut2

Automaton intersection(const Automaton& aut1, const Automaton& aut2) {
    Automaton result; // Automate résultant
    IdxSet<std::pair<int, int>> pairs; // Ensemble des paires d'états (un état de aut1 et un état de aut2)
    IdxSet<int> to_be_treated;         // File des états (paires) à traiter

    // Afficher les caractères communs entre les deux alphabets pour information (facultatif)
    std::cout << "Alphabet commun : ";
    for (char c : aut1.get_alphabet()) {
        if (aut2.get_alphabet().mem(c)) {
            std::cout << c << " "; // Affiche chaque caractère présent dans les deux alphabets
        }
    }
    std::cout << std::endl;

    // Étape 1 : Ajouter les paires d'états initiaux
    for (int init1 : aut1.get_inits()) { // Parcourt les états initiaux de aut1
        for (int init2 : aut2.get_inits()) { // Parcourt les états initiaux de aut2
            std::pair<int, int> initPair = {init1, init2}; // Crée une paire (init1, init2)
            int p = pairs.addindex(initPair); // Ajoute la paire à l'ensemble des paires avec un index unique
            result.add_init(p); // Ajoute l'état correspondant dans l'automate résultant comme état initial
            to_be_treated.add(p); // Ajoute cet état à la file des états à traiter
        }
    }

    // Étape 2 : Parcourir les paires d'états pour construire les transitions
    while (!to_be_treated.is_empty()) { // Tant qu'il reste des paires à traiter
        int p = to_be_treated.choose(); // Récupère une paire à traiter
        auto [p1, p2] = pairs.at(p); // Décompose la paire en ses deux états (p1 de aut1 et p2 de aut2)

        // Si les deux états sont finaux, l'état dans l'automate résultant est marqué comme final
        if (aut1.is_final(p1) && aut2.is_final(p2)) {
            result.add_final(p); // Marque cet état comme final
        }

        // Étape 3 : Traiter les transitions pour chaque caractère commun des alphabets
        for (char c : aut1.get_alphabet()) { // Parcourt chaque caractère de l'alphabet de aut1
            if (aut2.get_alphabet().mem(c)) { // Vérifie si le caractère est aussi dans l'alphabet de aut2
                auto states1 = aut1.out_states(p1, c); // États atteignables à partir de p1 avec le caractère c
                auto states2 = aut2.out_states(p2, c); // États atteignables à partir de p2 avec le caractère c

                if (!states1.is_empty() && !states2.is_empty()) { // Si les deux ensembles d'états atteignables ne sont pas vides
                    for (int q1 : states1) { // Parcourt chaque état atteignable de aut1
                        for (int q2 : states2) { // Parcourt chaque état atteignable de aut2
                            std::pair<int, int> nextPair = {q1, q2}; // Crée une paire (q1, q2)
                            int q;

                            if (!pairs.mem(nextPair)) { // Si la paire n'existe pas déjà
                                q = pairs.addindex(nextPair); // Ajoute la paire avec un nouvel index
                                to_be_treated.add(q); // Ajoute cette nouvelle paire à la file des états à traiter
                            } else {
                                q = pairs.index(nextPair); // Récupère l'index existant de la paire
                            }

                            result.add_trans(p, c, q); // Ajoute une transition entre les deux paires dans l'automate résultant
                        }
                    }
                }
            }
        }
    }

    return result; // Retourne l'automate résultant
}




// Fonction determinize() pour convertir un automate non déterministe (NFA) en automate déterministe (DFA)
// Cette fonction crée un DFA où chaque état représente un ensemble d'états du NFA
Automaton determinize(Automaton aut) {
    Automaton det; // Automate déterministe à construire
    IdxSet<IdxSet<int>> stateSets; // Ensemble des ensembles d'états du NFA (chaque état du DFA correspond à un ensemble d'états du NFA)

    // Étape 1 : Ajouter l'ensemble des états initiaux
    // L'état initial du DFA correspond à l'ensemble des états initiaux du NFA
    stateSets.add(aut.get_inits()); // Ajoute l'ensemble des états initiaux du NFA
    int init = stateSets.index(aut.get_inits()); // Indexe cet ensemble comme l'état initial du DFA
    det.add_init(init); // Ajoute cet état comme initial dans le DFA

    // Étape 2 : Parcourir les ensembles d'états du NFA pour construire les états et transitions du DFA
    for (size_t i = 0; i < stateSets.size(); ++i) { // Parcourt chaque ensemble d'états
        IdxSet<int> current = stateSets.at(i); // Récupère l'ensemble d'états courant correspondant à un état du DFA

        // Parcourt chaque caractère de l'alphabet du NFA
        for (char c : aut.get_alphabet()) {
            // Utilise successors() pour calculer les états accessibles depuis cet ensemble avec la lettre `c`
            IdxSet<int> next = successors(aut, current, c);

            if (!stateSets.mem(next) && !next.is_empty()) { // Si cet ensemble d'états n'existe pas déjà et qu'il n'est pas vide
                stateSets.add(next); // Ajoute cet ensemble d'états comme un nouvel état dans le DFA
            }
            if (!next.is_empty()) { // Ajoute une transition seulement si l'ensemble d'états accessible n'est pas vide
                det.add_trans(i, c, stateSets.index(next)); // Ajoute une transition dans le DFA
            }
        }

        // Vérifie si cet ensemble d'états contient un état final du NFA
        for (int state : current) { // Parcourt chaque état dans l'ensemble courant
            if (aut.is_final(state)) { // Si un des états de cet ensemble est final dans le NFA
                det.add_final(i); // Marque cet état comme final dans le DFA
                break; // Pas besoin de vérifier les autres états de cet ensemble
            }
        }
    }

    return det; // Renvoie l'automate déterministe construit
}




// Fonction complement() pour construire l'automate reconnaissant le complément d'un langage
// L'automate résultant accepte tous les mots qui ne sont pas acceptés par l'automate d'origine
Automaton complement(Automaton aut) {
    // Étape 1 : Déterminisation
    // Convertit l'automate non déterministe en un automate déterministe
    Automaton detAut = determinize(aut);

    // Étape 2 : Complétion de l'automate
    // Complète l'automate en ajoutant un état puit pour gérer les transitions manquantes
    int sinkState = detAut.newstate(); // Crée un nouvel état puit
    IdxSet<char> alphabet = detAut.get_alphabet(); // Récupère l'alphabet de l'automate

    // Parcourt tous les états existants de l'automate
    for (int state : detAut) {
        IdxSet<char> outLetters = detAut.out_letters(state); // Récupère les lettres sortantes de cet état
        for (char c : alphabet) { // Parcourt chaque lettre de l'alphabet
            if (!outLetters.mem(c)) { // Si aucune transition n'existe pour cette lettre
                detAut.add_trans(state, c, sinkState); // Ajoute une transition vers l'état poubelle
            }
        }
    }

    // Ajouter les transitions pour l'état puit
    for (char c : alphabet) { // Pour chaque lettre de l'alphabet
        detAut.add_trans(sinkState, c, sinkState); // L'état puit boucle sur lui-même pour toutes les lettres
    }

    // Étape 3 : Inverser les états finaux
    // Les états finaux de l'automate complément sont les états non finaux de l'automate complété
    IdxSet<int> newFinals; // Crée un nouvel ensemble pour les états finaux
    for (int state : detAut) { // Parcourt tous les états de l'automate déterministe
        if (!detAut.is_final(state)) { // Si l'état n'est pas final dans l'automate original
            newFinals.add(state); // Ajoute cet état comme final dans l'automate complément
        }
    }

    // Applique les nouveaux états finaux à l'automate
    detAut.get_finals().clear(); // Efface les anciens états finaux
    for (int state : newFinals) {
        detAut.add_final(state); // Ajoute les nouveaux états finaux
    }

    // Retourne l'automate complément
    return detAut;
}





int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    Automaton a4({0},{{0,'a',0},{0,'b',0}, {0,'a',1}},{1});
    std::cout << appartient(a4,"ba") << std::endl;
    std::cout << appartient(a4,"abab") << std::endl;


    // automate simple qui teste toutes les methodes sans lintersection (marche bien)


    std::cout << "\n +++Minimization+++" << std::endl;

    // Définir l'automate initial
    Automaton abc({0}, {{0, 'a', 1}, {1, 'b', 2}, {2, 'c', 3}}, {3});
    abc.add_trans(0, {'a', 'b', 'c'}, 0);
    abc.add_trans(3, {'a', 'b', 'c'}, 3);

    // Afficher l'automate de départ
    std::cout << "\n Automate de départ" << std::endl;
    abc.print();

    // Appliquer la déterminisation
    std::cout << "\n Déterminization " << std::endl;
    Automaton det_abc = determinize(abc);
    det_abc.print();

    // Appliquer la réduction (trim) avant la minimisation
    std::cout << "\n Trim avant Minimization " << std::endl;
    Automaton trimmed_abc = trim(det_abc);
    trimmed_abc.print();

    // Appliquer la minimisation sur l'automate réduit
    std::cout << "\n Minimization déter " << std::endl;
    Automaton min_abc = trimmed_abc.minimize();
    min_abc.print();

    // Deuxième exemple d'automate
    std::cout << "\n +++Minimization 2+++" << std::endl;
    Automaton ac_bc({0}, {{0, 'a', 1}, {0, 'b', 2}, {1, 'c', 3}, {2, 'c', 3}}, {3});

    // Appliquer trim et minimisation directement
    trim(ac_bc).minimize().print();




    return a.exec();

}
