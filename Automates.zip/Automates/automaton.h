/**
 * @author Gérard Cécé
 * Et utilisation version gratuite de ChatGPT pour rédiger plus
 * rapidement, ou une première version de, certaines parties.
 * @date 2024-09-27
 * @brief Classe Automaton de gestion d'automates finis non déterministe
 *
 *
 */

// CYNTHIA AYETOLOU

#ifndef AUTOMATON_H
#define AUTOMATON_H

#include <iostream>
#include <idxset.h>

#include <map>
#include <tuple>

// pour print(...)
#include <functional>    // Pour std::function
#include <string>        // Pour std::string et std::to_string

// #include <utility> // Pour l'affichage de tuple

using namespace std;

// Pour les epsilon-transitions
const char epsilon = 0;


// Classe Automaton
class Automaton {
private:
    int nb_states;                  // Nombre d'états. L'ensemble des états
    // est {0,..., nb_states -1 }
    IdxSet<int> inits;              // Ensemble des états initiaux
    IdxSet<char> alphabet;
    IdxSet<std::tuple<int, char, int>> transitions; // Ensemble des transitions
    IdxSet<int> finals;             // Ensemble des états finaux

public:
    // Constructeur par défaut : ensembles vides, nb_states = 0
    Automaton() : nb_states(0) {}

    // Constructeur à partir de vectors
    // VERIFIER QUE nb_states est mis à jour
    Automaton(const std::vector<int>& init_states,
              const std::vector<std::tuple<int, char, int>>& transitions,
              const std::vector<int>& final_states) : nb_states(0) {
        // Initialisation des états initiaux via add_init
        add_init(init_states);

        // Initialisation des transitions via add_trans
        add_trans(transitions);

        // Initialisation des états finaux via add_final
        add_final(final_states);
    }

    // Retourne le nombre d'états de l'automate
    int size() const {
        return nb_states;
    }


    // Ajoute à l'automate un nouvel état et le retourne.
    int newstate() {
        nb_states++;               // Incrémenter nb_states pour ajouter un nouvel état
        return nb_states - 1;      // Retourne la valeur avant l'incrémentation
    }

    // Ajoute un entier e comme état initial de l'automate. Si ce n'est pas
    // déjà le cas, ajoute tous les entiers inférieurs à e comme états de
    // l'automate
    void add_init(int e) {
        // Ajouter à l'ensemble des états initiaux
        inits.add(e);

        // Si l'état est supérieur ou égal à nb_states, on met à jour nb_states
        if (e >= nb_states) {
            nb_states = e + 1;
        }
    }


    // ajoute plusieurs états initiaux via un vector de int
    void add_init(const std::vector<int>& states) {
        for (int e : states) {
            add_init(e);  // Applique add_init à chaque entier du tableau
        }
    }

    const IdxSet<int>& get_inits() const {
        return inits;
    }

    const IdxSet<tuple<int,char,int>>& get_trans() const {
        return transitions;
    }

    // Fonction membre pour ajouter un état final
    void add_final(int e) {

        // Ajouter à l'ensemble des états finaux
        finals.add(e);

        // Si l'état est supérieur ou égal à nb_states, on met à jour nb_states
        if (e >= nb_states) {
            nb_states = e + 1;
        }
    }

    // ajoute plusieurs états finaux via un vector de int
    // on pourra ainsi écrire : add_finalv({2,5,3,6,2})
    // le 2 ne sera inséré qu'une seule fois.
    void add_final(const std::vector<int>& states) {
        for (int e : states) {
            add_final(e);  // Applique add_final à chaque entier du tableau
        }
    }

    bool is_final (int q) const {
        return finals.mem(q);
    }

    // Fonction membre pour ajouter une lettre à l'alphabet
    void add_letter(int e) {
        alphabet.add(e);
    }

    // ajoute plusieurs lettres à l'alphabet via un vector de char
    // on pourra ainsi écrire : add_letter({'d','g','A','g'})
    // le 'g' ne sera inséré qu'une seule fois.
    void add_letter(const std::vector<char>& letters) {
        for (char c : letters) {
            add_letter(c);
        }
    }

    // ajoute plusieurs lettres à l'alphabet via un IdxSet<char>
    // on pourra ainsi écrire : add_letter(alph)
    void add_letter(const IdxSet<char>& letters) {
        for (char c : letters) {
            add_letter(c);
        }
    }

    const IdxSet<char>& get_alphabet() const {
        return alphabet;
    }

    // Fonction membre pour ajouter une transition src -c-> dst
    // src et dst sont aussi ajoutés à l'ensemble des états ainsi que tout
    // état d'index inférieur. La lettre c est aussi ajoutée à l'alphabet
    // de l'automate.
    void add_trans(int src, char c, int dst) {

        // Ajouter à l'ensemble des transitions
        transitions.add({src,c,dst});

        // Si src ou dst est supérieur ou égal à nb_states, on met à jour nb_states
        if (src >= nb_states) {
            nb_states = src + 1;
        }
        if (dst >= nb_states) {
            nb_states = dst + 1;
        }
        add_letter(c);
    }

    // ajoute plusieurs transitions via un vecteur de tuples
    // on pourra ainsi écrire :
    //    add_trans({
    //        {1, 'a', 2},
    //        {3, 'b', 2},
    //        {0, 'a', 3}
    //       })
    void add_trans(const std::vector<std::tuple<int, char, int>>& transitions) {
        for (const auto& t : transitions) {
            add_trans(std::get<0>(t), std::get<1>(t), std::get<2>(t));
        }
    }

    // Pour pouvoir écrire add_trans(src, {'a','b','c'},dst). A pour effet
    // d'ajouter les transitions :
    //   src -'a'-> dst
    //   src -'b'-> dst
    //   src -'c'-> dst
    void add_trans(int src, const std::vector<char> letters, int dst) {
        for (const auto& c : letters) {
            add_trans(src, c, dst);
        }
    }

    void add_trans(int src, const IdxSet<char> letters, int dst) {
        for (const auto& c : letters) {
            add_trans(src, c, dst);
        }
    }

    const IdxSet<int>& get_finals() const {
        return finals;
    }

    // out_letters(q) retourne un IdxSet<char> contenant tous les caractères c tels
    // qu'il existe dans l'automate une transition q -c-> q'
    IdxSet<char> out_letters(int q) const {
        IdxSet<char> letters; // Créer un IdxSet pour stocker les lettres
        for (const auto& t : transitions) { // t parcourt les transition de l'automate
            if (std::get<0>(t) == q) { // Vérifier si le src est égal à q
                letters.add(std::get<1>(t)); // Ajouter la lettre au IdxSet
            }
        }
        return letters; // Retourner le IdxSet contenant les lettres
    }

    // out_states(q,c) retourne un IdxSet contenant tous les int dst tels
    // qu'il existe dans l'automate une transition q -c-> dst
    IdxSet<int> out_states(int q, char c) const {
        IdxSet<int> states; // Créer un IdxSet pour stocker les états de destination
        for (const auto& t : transitions) {
            if (std::get<0>(t) == q && std::get<1>(t) == c) { // Vérifier si src est égal à q et si la lettre est c
                states.add(std::get<2>(t)); // Ajouter dst au IdxSet
            }
        }
        return states; // Retourner le IdxSet contenant les états de destination
    }



    // Fonction pour afficher l'automate (optionnelle pour le debug)
    void print() const {
        // Affiche le nombre d'états
        std::cout << "Number of states: " << nb_states << std::endl;

        // Affiche les états initiaux
        std::cout << "Initial states: " << inits << std::endl;

        // Affiche l'alphabet
        std::cout << "Alphabet: " << alphabet << std::endl;

        // Affiche les transitions
        std::cout << "Transitions: {" << std::endl;
        for (const auto& t : transitions) {
            std::cout << "  " << std::get<0>(t) << " -" << std::get<1>(t)
                      << "-> " << std::get<2>(t) << std::endl;
        }
        std::cout << "}" << std::endl;

        // Affiche les états finaux
        std::cout << "Final states: " << finals << std::endl;
    }

    void print(std::function<std::string(int)> st2String) const {
        // Affiche le nombre d'états
        std::cout << "Number of states: " << nb_states << std::endl;

        // Affiche les états initiaux
        std::cout << "Initial states: {";
        bool first = true;
        for (const auto& q : inits) {
            if (!first) {
                std::cout << ", ";
            }
            std::cout << st2String(q);
            first = false;
        }
        std::cout << "}" << std::endl;

        // Affiche l'alphabet
        std::cout << "Alphabet: " << alphabet << std::endl;

        // Affiche les transitions
        std::cout << "Transitions: {" << std::endl;
        for (const auto& t : transitions) {
            std::cout << "  " << st2String(std::get<0>(t)) << " -" << std::get<1>(t)
                      << "-> " << st2String(std::get<2>(t)) << std::endl;
        }
        std::cout << "}" << std::endl;

        // Affiche les états finaux
        std::cout << "Final states: {";
        first = true;
        for (const auto& q : finals) {
            if (!first) {
                std::cout << ", ";
            }
            std::cout << st2String(q);
            first = false;
        }
        std::cout << "}" << std::endl;
    }


    class StateIterator {
    private:
        int current;  // L'état actuel que l'itérateur parcourt

    public:
        // Constructeur de l'itérateur
        StateIterator(int start) : current(start) {}

        // Surcharge de l'opérateur * (déréférencement)
        int operator*() const {
            return current;  // Retourne l'état actuel
        }

        // Surcharge de l'opérateur ++ (incrémentation)
        StateIterator& operator++() {
            ++current;  // Passe à l'état suivant
            return *this;
        }

        // Surcharge de l'opérateur != (comparaison de fin d'itération)
        bool operator!=(const StateIterator& other) const {
            return current != other.current;
        }
    };

    // Méthode begin() pour obtenir l'itérateur au premier état
    StateIterator begin() const {
        return StateIterator(0);  // Commence à l'état 0
    }

    // Méthode end() pour obtenir l'itérateur après le dernier état
    StateIterator end() const {
        return StateIterator(nb_states);  // L'itérateur se termine à nb_states (non inclus)
    }

// ajout des fonctions in_letters et in_states


    // Méthode in_letters() pour obtenir toutes les lettres qui permettent d'atteindre un état donné
    IdxSet<char> in_letters(int q) const {
        IdxSet<char> letters; // Initialise un ensemble pour stocker les lettres trouvées

        for (const auto& t : transitions) { // Parcourt toutes les transitions définies dans l'automate
            if (std::get<2>(t) == q) { // Vérifie si l'état de destination de la transition correspond à l'état q
                letters.add(std::get<1>(t)); // Ajoute la lettre de la transition à l'ensemble letters
            }
        }

        return letters; // Renvoie l'ensemble des lettres trouvées menant à l'état q
    }

    // Méthode in_states() pour identifier les états sources menant à un état donné avec une lettre spécifique
    IdxSet<int> in_states(char c, int q) const {
        IdxSet<int> states; // Initialise un ensemble pour stocker les états sources trouvés

        for (const auto& t : transitions) { // Parcourt toutes les transitions définies dans l'automate
            // Vérifie si l'état de destination correspond à q et si la lettre utilisée est égale à c
            if (std::get<2>(t) == q && std::get<1>(t) == c) {
                states.add(std::get<0>(t)); // Ajoute l'état source de la transition à l'ensemble states
            }
        }

        return states; // Renvoie l'ensemble des états sources trouvés pour la lettre c et l'état q
    }



    // Méthode get_finals() pour accéder à l'ensemble des états finaux de l'automate
    // je l'ai ajouté pour pouvoir acceder directement aux etats finaux pour la realisation
    // du complementaire

    IdxSet<int>& get_finals() {
        return finals; // Retourne une référence à l'ensemble finals qui contient les états finaux
    }



    // Méthode get_all_states() pour obtenir l'ensemble de tous les états de l'automate
    IdxSet<int> get_all_states() const {
        IdxSet<int> states; // Initialise un ensemble vide pour stocker tous les états de l'automate

        // Ajouter tous les états initiaux à l'ensemble
        for (int init : get_inits()) {
            states.add(init); // Ajoute chaque état initial
        }

        // Ajouter tous les états finaux à l'ensemble
        for (int final : get_finals()) {
            states.add(final); // Ajoute chaque état final
        }

        // Ajouter les états impliqués dans les transitions
        for (const auto& t : get_trans()) {
            states.add(std::get<0>(t)); // Ajoute l'état source de la transition
            states.add(std::get<2>(t)); // Ajoute l'état destination de la transition
        }

        return states; // Retourne l'ensemble contenant tous les états de l'automate
    }


    // Méthode transitionExists() pour vérifier l'existence d'une transition spécifique
    // Cette méthode retourne true si une transition src -c-> dst existe dans l'automate, sinon false
    bool transitionExists(int src, char c, int dst) const {
        for (const auto& t : get_trans()) { // Parcourt toutes les transitions de l'automate
            // Vérifie si la transition correspond aux paramètres donnés
            if (std::get<0>(t) == src && std::get<1>(t) == c && std::get<2>(t) == dst) {
                return true; // Retourne true dès qu'une transition correspondante est trouvée
            }
        }
        return false; // Retourne false si aucune transition correspondante n'a été trouvée
    }


    // Méthode computePartition() pour calculer la partition des états d'un automate
    // Cette méthode implémente l'algorithme de minimisation du cours pour diviser les états en blocs d'équivalence
    IdxSet<IdxSet<int>> computePartition() const {
        IdxSet<IdxSet<int>> P; // Initialise la partition des états
        IdxSet<int> QF = get_finals();  // Ensemble des états finaux
        IdxSet<int> QnQF;              // Ensemble des états non finaux

        // Obtenir tous les états de l'automate(je l'ai defini plus haut)
        IdxSet<int> Q = get_all_states();

        // Séparation des états finaux et non finaux
        for (int state : Q) { // Pour chaque état de l'automate
            if (!QF.mem(state)) { // Si l'état n'appartient pas aux états finaux
                QnQF.add(state);  // Alors on l'ajoute à l'ensemble des états non finaux
            }
        }

        // Ajouter les blocs finaux et non finaux à la partition initiale
        if (!QF.is_empty()) { // Si l'ensemble des états finaux n'est pas vide
            P.add(QF);        // Alors on ajoute les états finaux comme un bloc séparé dans la partition
        }
        if (!QnQF.is_empty()) { // Si l'ensemble des états non finaux n'est pas vide
            P.add(QnQF);        // Alors on ajoute les états non finaux comme un autre bloc
        }

        bool doItAgain = true; // Initialise la variable pour indiquer si on doit continuer à affiner la partition
        while (doItAgain) { // Tant qu'il reste des blocs à diviser
            doItAgain = false; // On suppose qu'il n'y a plus de divisions nécessaires, sauf preuve du contraire
            IdxSet<IdxSet<int>> newPartition; // Nouvelle partition qui sera calculée à cette étape

            // Parcourt chaque bloc de la partition actuelle
            for (const auto& B : P) {
                if (B.is_empty()) continue; // Si le bloc est vide, on l'ignore et passe au suivant

                IdxSet<int> B1, B2;  // Sous-blocs qui vont contenir les états divisés du bloc B
                int q = *B.begin();  // Prend un état quelconque (représentant) dans le bloc B

                // Comparer tous les autres états du bloc B avec le représentant q
                for (int qPrime : B) {
                    bool sameBlock = true; // Suppose que qPrime appartient au même sous-bloc que q

                    // Vérifie les transitions sortantes de q et qPrime pour chaque lettre de l'alphabet
                    for (char a : get_alphabet()) {
                        IdxSet<int> deltaQ = out_states(q, a);        // États atteints à partir de q avec la lettre a
                        IdxSet<int> deltaQPrime = out_states(qPrime, a); // États atteints à partir de qPrime avec a

                        bool inSameBlock = false; // Suppose que les transitions mènent au même bloc

                        // Parcourt tous les blocs de la partition actuelle pour comparer les destinations
                        for (const auto& block : P) {
                            if ((deltaQ.is_empty() && deltaQPrime.is_empty()) || // Si les deux ensembles sont vides
                                (!deltaQ.is_empty() && !deltaQPrime.is_empty() && // Ou si les deux ensembles ne sont pas vides
                                 block.mem(*deltaQ.begin()) == block.mem(*deltaQPrime.begin()))) { // Et qu'ils mènent au même bloc
                                inSameBlock = true; // Alors les deux transitions sont équivalentes
                                break; // Arrête la vérification pour ce bloc
                            }
                        }

                        if (!inSameBlock) { // Si q et qPrime mènent à des blocs différents
                            sameBlock = false; // Alors qPrime ne peut pas être dans le même sous-bloc que q
                            break; // Arrête la comparaison pour cet état
                        }
                    }

                    // Ajoute qPrime au sous-bloc approprié
                    if (sameBlock) {
                        B1.add(qPrime); // Si qPrime est équivalent à q, on l'ajoute au sous-bloc B1
                    } else {
                        B2.add(qPrime); // Sinon, on l'ajoute au sous-bloc B2
                    }
                }

                // Si le bloc a été divisé en deux sous-blocs
                if (!B2.is_empty()) {
                    doItAgain = true;          // On indique qu'une nouvelle itération sera nécessaire
                    newPartition.add(B1);      // Ajoute le premier sous-bloc à la nouvelle partition
                    newPartition.add(B2);      // Ajoute le second sous-bloc à la nouvelle partition
                } else {
                    newPartition.add(B);       // Sinon, conserve le bloc d'origine sans le diviser
                }
            }

            P = newPartition; // Met à jour la partition avec la nouvelle partition calculée
        }

        return P; // Retourne la partition finale contenant les blocs d'états équivalents
    }


    // Méthode constructMinimalAutomaton() pour construire un automate minimal
    // Cette méthode prend une partition d'états et crée un nouvel automate où chaque bloc correspond à un seul état
    Automaton constructMinimalAutomaton(const IdxSet<IdxSet<int>>& partition) const {
        Automaton minimized; // Crée un nouvel automate qui sera minimisé
        std::map<int, int> stateMap; // Associe chaque état original à un état dans l'automate minimisé

        // Étape 1 : Associer chaque bloc de la partition à un nouvel état dans l'automate minimisé
        for (const IdxSet<int>& block : partition) { // Parcourt chaque bloc de la partition
            int newState = minimized.newstate(); // Crée un nouvel état dans l'automate minimisé

            // Mapper chaque état original du bloc vers le nouvel état créé
            for (int oldState : block) { // Pour chaque état dans le bloc
                stateMap[oldState] = newState; // Associe cet état au nouvel état
            }

            // Vérifier si le bloc contient un état initial de l'automate d'origine
            for (int oldState : block) { // Parcourt les états du bloc
                if (get_inits().mem(oldState)) { // Si un des états est un état initial
                    minimized.add_init(newState); // Ajoute le nouvel état comme état initial dans l'automate minimisé
                    break; // Un seul état initial suffit, donc on sort de la boucle
                }
            }

            // Vérifier si le bloc contient un état final de l'automate d'origine
            for (int oldState : block) { // Parcourt les états du bloc
                if (get_finals().mem(oldState)) { // Si un des états est un état final
                    minimized.add_final(newState); // Ajoute le nouvel état comme état final dans l'automate minimisé
                    break; // Un seul état final suffit, donc on sort de la boucle
                }
            }
        }

        // Étape 2 : Ajouter les transitions entre les nouveaux états
        for (const auto& block : partition) { // Parcourt chaque bloc de la partition
            int newState = stateMap[*block.begin()]; // Récupère l'état minimisé correspondant au bloc

            for (char a : get_alphabet()) { // Parcourt chaque symbole de l'alphabet
                IdxSet<int> destinations; // Ensemble pour stocker les états de destination

                // Collecter toutes les destinations possibles à partir des états du bloc avec le symbole a
                for (int oldState : block) { // Parcourt les états du bloc
                    destinations.add(out_states(oldState, a)); // Ajoute les destinations possibles pour cet état et ce symbole
                }

                if (!destinations.is_empty()) { // Si des destinations existent pour ce symbole
                    int targetState = stateMap[*destinations.begin()]; // Récupère l'état minimisé correspondant à la destination

                    // Vérifier si une transition identique n'existe pas déjà
                    if (!minimized.transitionExists(newState, a, targetState)) {
                        minimized.add_trans(newState, a, targetState); // Ajoute la transition dans l'automate minimisé
                    }
                }
            }
        }

        return minimized; // Retourne l'automate minimisé
    }



    // Méthode minimize() pour réduire l'automate en son automate minimal
    // Cette méthode utilise la partition des états pour regrouper les états équivalents
    Automaton minimize() const {
        // Étape 1 : Calculer la partition correspondant à la relation d'équivalence ∼
        // Cette partition regroupe les états qui sont équivalents (c'est-à-dire ayant le même comportement dans l'automate)
        IdxSet<IdxSet<int>> partition = computePartition();

        // Étape 2 : Construire l'automate minimal à partir de la partition
        // Chaque bloc de la partition devient un état unique dans l'automate minimisé
        return constructMinimalAutomaton(partition);
    }




};

#endif // AUTOMATON_H
