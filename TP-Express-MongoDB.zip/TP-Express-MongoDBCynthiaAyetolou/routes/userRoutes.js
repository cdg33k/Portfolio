const express = require("express"); 
const User = require("../models/User"); 
const router = express.Router(); 
//  Ajouter un utilisateur 
router.post("/", async (req, res) => { 
try { 
const newUser = new User(req.body); 
await newUser.save(); 
res.status(201).json(newUser); 
} catch (error) { 
res.status(400).json({ error: error.message }); 
} 
}); 
//  Récupérer tous les utilisateurs 
router.get("/", async (req, res) => { 
const users = await User.find(); 
res.json(users); 
}); 
// Récupérer un utilisateur par ID 
router.get("/:id", async (req, res) => { 
const user = await User.findById(req.params.id); 
res.json(user); 
}); 
//  Modifier un utilisateur 
router.put("/:id", async (req, res) => { 
const updatedUser = await User.findByIdAndUpdate(req.params.id, req.body, { new: 
true }); 
res.json(updatedUser); 
}); 
// Supprimer un utilisateur 
router.delete("/:id", async (req, res) => { 
await User.findByIdAndDelete(req.params.id); 
res.json({ message: "Utilisateur supprimé" }); 
}); 
module.exports = router;