// Scrpt simple

const message = "ceci est un script Node.js";
console.log(message);

//Ajout des arguments
const args = process.argv.slice(2);
console.log("Arguments recus : ", args);

// Lecture du fichier txt\
const fs = require ('fs');
fs.readFile('example.txt', 'utf-8', (err, data) => {
    if (err) throw err;
    console.log(data);
})


//ecrire dans le ficher texte

fs.writeFile('output.txt', 'Bonjour encore Node.js', (err) =>{
    if (err) throw err;
    console.log('Fichier ecrit avec succes')
})


// lir et mettre en majuscule
fs.readFile('example.txt', 'utf8', (err, data) => {
    if (err) throw err;
    fs.writeFile('uppercase.txt', data.toUpperCase(), (err) => {
        if (err) throw err;
        console.log('Conversion terminée ');
    });
});