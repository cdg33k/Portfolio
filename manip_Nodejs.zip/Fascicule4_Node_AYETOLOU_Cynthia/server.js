const http = require('http');
const fs = require('fs');

const server = http.createServer((req, res) => {
    fs.readFile('message.txt', 'utf8', (err, data) => {
        if (err) {
            res.writeHead(500, {'Content-Type': 'text/plain'});
            res.end('Erreur serveur');
            return;
        }

        const newMessage = `${data}\nNouvelle visite le ${new Date().toLocaleString()}`;
        fs.writeFile('message.txt', newMessage, (err) => {
            if (err) {
                res.writeHead(500, {'Content-Type': 'text/plain'});
                res.end('Erreur lors de l\'écriture');
                return;
            }

            res.writeHead(200, {'Content-Type': 'text/plain'});
            res.end(newMessage);
        });
    });
});

server.listen(3000, () => {
    console.log('Serveur démarré sur http://localhost:3000');
});
