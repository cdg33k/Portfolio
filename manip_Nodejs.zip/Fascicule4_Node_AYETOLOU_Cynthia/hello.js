console.log("Hello, Node.js !");
const _ = require('lodash')
console.log(_.chunk([1, 2,3,4], 2));
