#include "canvas.h"
#include <QPainter>
#include <QFont>
#include <QDebug>

Canvas::Canvas(QWidget *parent)
    : QWidget{parent} {
    setMouseTracking(true); // Activer le suivi de la souris

    // calcul de la position initiale du rectangle pour le centrer dans la fenetre
    int rectWidth = 100;
    int rectHeight = 60;
    rectangleTopLeft = QPoint((width() - rectWidth) / 2, (height() - rectHeight) / 2);
}

void Canvas::paintEvent(QPaintEvent *) {
    QPainter painter(this);

    // Remplir l'arrière-plan avec du gris clair
    painter.fillRect(0, 0, width(), height(), Qt::lightGray);

    // Dessiner les cercles avec des couleurs dynamiques
    if (width() > 130 && height() > 160) { // ici je vérifie les dimensions minimales requises car a un moment mes objets bougaient partout
        painter.setPen(QPen(Qt::black, 5));
        painter.setBrush(isLeftCircleHovered ? Qt::green : Qt::yellow);
        painter.drawEllipse(50, height() / 2 - 80, 80, 80);

        painter.setBrush(isRightCircleHovered ? Qt::green : Qt::yellow);
        painter.drawEllipse(width() - 130, height() / 2 - 80, 80, 80);
    }

    // Dessiner le rectangle
    if (rectangleTopLeft.x() >= 0 && rectangleTopLeft.y() >= 0 &&
        rectangleTopLeft.x() + 100 <= width() &&
        rectangleTopLeft.y() + 60 <= height()) {
        QColor rectangleColor = isDraggingRectangle ? QColor(0, 255, 0, 128) : QColor(255, 165, 0, 128); // Vert si survolé, jaune sinon
        painter.setBrush(rectangleColor);
        painter.setPen(QPen(Qt::blue, 3));
        painter.drawRect(rectangleTopLeft.x(), rectangleTopLeft.y(), 100, 60);
    }

    // jai repris les lignes de repere pour etre sure que les cercles sont a la bonne place
    painter.setPen(QPen(Qt::gray, 1, Qt::DashLine));
    painter.drawLine(width() / 2, 0, width() / 2, height());  // verticale
    painter.drawLine(0, height() / 2, width(), height() / 2); //horizontale

    //  les textes dans les formes
    painter.setPen(QPen(Qt::black, 2));
    painter.setFont(QFont("Arial", 30, QFont::Bold));
    painter.drawText(50, height() / 2 - 80, 80, 80, Qt::AlignCenter, "<"); //fleche gauche
    painter.drawText(width() - 130, height() / 2 - 80, 80, 80, Qt::AlignCenter, ">"); // fleche droite
    painter.drawText(rectangleTopLeft.x(), rectangleTopLeft.y(), 100, 60, Qt::AlignCenter, QString::number(rectangleValue)); // nombre dans le rectangle
}


// gestion des clics de la souris

void Canvas::mousePressEvent(QMouseEvent *event) {
    QPoint cursorPos = event->pos(); // Récupérer la position du curseur

// Définir les zones des cercles

    QRect leftCircle(50, height() / 2 - 80, 80, 80);
    QRect rightCircle(width() - 130, height() / 2 - 80, 80, 80);

    // Si le clic est dans le cercle gauche, décrémenter la valeur
    if (leftCircle.contains(cursorPos)) {
        rectangleValue = std::max(0, rectangleValue - 1);   // Limite inférieure à 0
        update(); // Redessiner
        return;
    }
// Si le clic est dans le cercle droit, incrémenter la valeur
    if (rightCircle.contains(cursorPos)) {
        rectangleValue = std::min(20, rectangleValue + 1); // Limite supérieure à 20
        update();
        return;
    }

    QRect rectangleBounds(rectangleTopLeft.x(), rectangleTopLeft.y(), 100, 60);
    if (rectangleBounds.contains(cursorPos)) {
        isDraggingRectangle = true;
        dragStartPosition = cursorPos - rectangleTopLeft;
        update();
    }
}



// les mouvements de la souris

void Canvas::mouseMoveEvent(QMouseEvent *event) {
    QPoint cursorPos = event->pos();

    // Vérifier les survols des cercles
    QRect leftCircle(50, height() / 2 - 80, 80, 80);
    QRect rightCircle(width() - 130, height() / 2 - 80, 80, 80);

    bool hoveredLeft = leftCircle.contains(cursorPos);
    bool hoveredRight = rightCircle.contains(cursorPos);

    if (hoveredLeft != isLeftCircleHovered || hoveredRight != isRightCircleHovered) {
        isLeftCircleHovered = hoveredLeft;
        isRightCircleHovered = hoveredRight;
        update(); // si letat a chang é, update
    }

    //  déplacement du rectangle
    if (isDraggingRectangle) {
        // Calcule la nouvelle position
        QPoint newTopLeft = cursorPos - dragStartPosition;

        // m'assurer que le rectangle reste dans les limites de la fenêtre
        // des fois quand je compile le rectangle est hors du cadre et jai un probleme
        // d'Allocation donc le programme se plante

        int rectWidth = 100;
        int rectHeight = 60;
        newTopLeft.setX(std::max(0, std::min(width() - rectWidth, newTopLeft.x())));
        newTopLeft.setY(std::max(0, std::min(height() - rectHeight, newTopLeft.y())));

        rectangleTopLeft = newTopLeft;
        update();
    }
}


//  relâchement de la souris
void Canvas::mouseReleaseEvent(QMouseEvent *) {

    if (isDraggingRectangle) {
        isDraggingRectangle = false; // Désactiver le mode de déplacement
        update(); // Revenir à l'état normal
    }
}


// Gestion du redimensionnement de la fenêtre
void Canvas::resizeEvent(QResizeEvent *event) {
    Q_UNUSED(event);

    // Recentre le rectangle lors du redimensionnement de la fenêtre
    int rectWidth = 100;
    int rectHeight = 60;
    rectangleTopLeft = QPoint((width() - rectWidth) / 2, (height() - rectHeight) / 2);

    update(); // Redessiner la fenêtre
}
