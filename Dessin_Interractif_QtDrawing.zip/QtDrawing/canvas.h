#ifndef CANVAS_H
#define CANVAS_H

#include <QWidget>
#include <QMouseEvent>

class Canvas : public QWidget {
    Q_OBJECT

public:
    explicit Canvas(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *) override;
    void resizeEvent(QResizeEvent *event) override;


private:
    bool isLeftCircleHovered = false;    // dis si le curseur survole le cercle gauche
    bool isRightCircleHovered = false;  // dis si le curseur survole le cercle droit
    bool isDraggingRectangle = false;   // dis si le rectangle est en cours de déplacement
    QPoint dragStartPosition;           // position initiale du curseur lors du clic
    QPoint rectangleTopLeft = QPoint(200, 150); // position initiale du rectangle
    int rectangleValue = 0;             // Valeur affichée dans le rectangle
};

#endif // CANVAS_H
