#ifndef HASHTABLE_H
#define HASHTABLE_H

#include "mylist.h"
#include <QString>

// Classe de base HashTable
class HashTable {
public:
    // Constructeur et destructeur
    HashTable(int p_size);
    virtual ~HashTable();

    // Méthode virtuelle pure pour obtenir la clé de hachage
    virtual int getKey(const QString& word) const = 0;

    // Méthodes pour rechercher et charger des mots
    bool find(const QString& word);
    bool loadFile(const QString &fileName);

protected:
    int size;       // Taille de la table de hachage
    MyList* table;  // Tableau de listes pour gérer les collisions
};

// Classe HashTableLetter utilisant la lettre initiale comme clé de hachage
class HashTableLetter : public HashTable {
public:
    HashTableLetter(int p_size);
    int getKey(const QString& word) const override;
};

// Classe HashTableSum utilisant la somme des valeurs ASCII pour calculer la clé
class HashTableSum : public HashTable {
public:
    HashTableSum(int p_size);
    int getKey(const QString& word) const override;
};

#endif // HASHTABLE_H
