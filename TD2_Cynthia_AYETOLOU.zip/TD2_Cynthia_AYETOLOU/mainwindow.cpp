#include "mainwindow.h"
#include "permutation.h"
#include "ui_mainwindow.h"
#include "mylist.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QDebug>

// Constructeur de la classe MainWindow, initialise l'interface utilisateur et charge les fichiers nécessaires
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
    ui(new Ui::MainWindow) {
    ui->setupUi(this);  // Configure l'interface utilisateur

    // Charger le fichier words5.txt pour remplir lstWord5 avec des mots de 5 lettres
    if (lstWord5.loadFile("C:/Users/cynth/Documents/TD2_Cynthia/data/words5.txt")) {
        qDebug() << "le fichier words5.txt est bien chargé ";
    } else {
        qDebug() << "Erreur lors du chargement du fichier words5.txt.";
    }

    /*
     * Partie pour configurer les actions dans le menu
     * (actuellement en commentaire)
     */

    menuGroup = new QActionGroup(this);
    menuGroup->addAction(ui->actionListe_Simple);
    menuGroup->addAction(ui->actionListe_tri_e);
    menuGroup->addAction(ui->actionTable_de_hashage_2);
    menuGroup->addAction(ui->actionTable_de_hashage_2);
    ui->actionListe_Simple->setChecked(true);


    // Message de bienvenue dans la barre de statut, affiché pour 5 secondes
    ui->statusbar->showMessage("Bonjour! Les statistiques s'afficheront ici", 5000);

    // Test de la classe Permutation avec trois lettres, pour générer toutes les permutations de "ABC"
    char src[3] = {'A', 'B', 'C'};
    Permutation<3> perm(src);  // Création de l'objet Permutation
    char res[4];               // Tableau pour stocker chaque permutation (taille 4 pour inclure le caractère nul)

    // Boucle pour générer et afficher les permutations de "ABC"
    for (int i = 0; i < 6; i++) {
        perm.word(3, i, res);   // Génère la permutation
        res[3] = 0;             // Ajoute le caractère nul pour marquer la fin de chaîne
        qDebug() << res;        // Affiche la permutation générée
    }

    // Ajouter un mot directement dans le dictionnaire
    dictionnaire.pushFront("arbre");

    // Chargement de mots depuis différents fichiers dans le dictionnaire
    dictionnaire.loadFile("C:/Users/cynth/Documents/TD2_Cynthia/data/words3.txt");
    dictionnaire.loadFile("C:/Users/cynth/Documents/TD2_Cynthia/data/words4.txt");
    dictionnaire.loadFile("C:/Users/cynth/Documents/TD2_Cynthia/data/words5.txt");
}

// Destructeur de la classe MainWindow, libère la mémoire allouée
MainWindow::~MainWindow() {
    delete ui;
    delete menuGroup;
}

// Slot appelé lors du clic sur le bouton "Generate" pour générer des combinaisons de mots et les afficher
void MainWindow::on_pushButton_clicked() {
    QString letters = ui->lineEdit->text();  // Récupère les lettres saisies par l'utilisateur

    // Vérifie si exactement 7 lettres sont saisies
    if (letters.size() == 7) {
        MyList validWords;  // Liste pour stocker les mots valides générés
        qDebug() << "Début de la génération des mots avec les lettres :" << letters;

        // Initialiser la barre de progression
        int totalComb = 2520;  // Nombre total de combinaisons de 5 lettres parmi 7
        ui->progressBar->setRange(0, totalComb);  // Définit la plage de la barre de progression
        ui->progressBar->setValue(0);  // Réinitialise la barre au début

        // Crée un objet Permutation pour générer des combinaisons de 5 lettres parmi les 7 lettres
        Permutation<7> perm(letters.toStdString().c_str());
        char res[6];  // Tableau pour stocker chaque combinaison (5 lettres + caractère nul)

        // Boucle pour générer toutes les combinaisons de 5 lettres parmi les 7
        for (int i = 0; i < totalComb; ++i) {
            if (perm.word(5, i, res)) {  // Génère une combinaison de 5 lettres
                QString word = QString::fromUtf8(res, 5);  // Convertit la combinaison en QString
                qDebug() << "Mot généré :" << word;

                // Vérifie si le mot existe dans lstWord5
                if (lstWord5.find(word)) {
                    validWords.insertPlaced(word);  // Ajoute le mot valide à validWords (sans doublon)
                    qDebug() << "Mot valide trouvé et inséré dans validWords :" << word;
                } else {
                    qDebug() << "Mot non trouvé dans lstWord5 :" << word;
                }
            }

            // Mettre à jour la barre de progression
            ui->progressBar->setValue(i + 1);
            qApp->processEvents();  // Rafraîchit l'interface utilisateur pour afficher la progression
        }

        // Afficher les mots valides dans la zone de texte textEdit
        ui->textEdit->clear();
        for (Element *mots = validWords.getFirst(); mots != nullptr; mots = mots->next) {
            ui->textEdit->append(mots->word);  // Affiche chaque mot valide
            qDebug() << "Mot affiché dans textEdit :" << mots->word;
        }

        // Si aucun mot valide n'est trouvé, afficher un message dans textEdit
        if (validWords.getFirst() == nullptr) {
            qDebug() << "Aucun mot valide trouvé dans validWords.";
            ui->textEdit->setText("Aucun mot valide trouvé.");
        }

    } else {
        // Si le nombre de lettres est incorrect, affiche un message d'erreur
          QMessageBox::critical(this, "Erreur", "ENTREZ 7 LETTRES MAJUSCULES");
        qDebug() << "Erreur : Nombre de lettres incorrect.";
    }
}
