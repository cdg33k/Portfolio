#ifndef PERMUTATION_H
#define PERMUTATION_H
#include <QString>
//#include <QDebug>

template<unsigned int N> class Permutation {

static int factorial(int n) {
    int fact=1;
    while (n>1) {
        fact*=n;
        n--;
    }
    return fact;
}

static int factorial(int n1, int n2) {
    int fact=1;
    while (n1>=n2) {
        fact*=n1;
        n1--;
    }
    return fact;
}

class LetterTree {
    int size;
public:
   /*
    LetterTree** children;
    char letter;

        LetterTree(char l, int s):letter(l),size(s) {

            */
    LetterTree** children;
    char letter;

    LetterTree(char l, int s) : letter(l), size(s) {
        if (size>0) {
                children = new LetterTree*[size];
                for (int i=0; i<size; i++) children[i]=nullptr;
        } else {
            children= nullptr;
        }
    }
    ~LetterTree() {
        if (size>0) {
            for (int i=0; i<size; i++) {
                delete children[i];
            }
            delete [] children;
        }
    }
    void word(unsigned int k,unsigned int n,unsigned int level,char res[N]) {
        int div = factorial(N-1-level,N-level-k+1);
        int i=n/div;
//        qDebug() << "n=" << n << " k=" << k << "div=" << div << " i=" << i << "res["<<level<<"]=" << children[i]->letter;

        res[level]=children[i]->letter;
        if (k>1) {
           children[i]->word(k-1,n%div,level+1,res);
        }
    }

};

private:
    LetterTree* children[N];

    LetterTree *createBranch(const char *letters, int n,int parentIndex) {
        LetterTree* newNode= new LetterTree(letters[parentIndex],n-1);
        if (n>1) {
            char *subLetters = new char[n-1];
            auto ptr=letters;
            int j=0;
            for (int i=0; i<n; i++) {
                if (i!=parentIndex) {
                    subLetters[j++]=*ptr;
                }
                ptr++;
            }
            for (int i=0; i<n-1; i++) {
                newNode->children[i]=createBranch(subLetters,n-1,i);
            }
            delete [] subLetters;
        }
        return newNode;
    }
public:
    Permutation(const char letters[N]) {
        for (unsigned int i=0; i<N; i++) {
            children[i]=createBranch(letters,N,i);
        }
    }

    ~Permutation() {
        for (int i=0; i<N; i++) {
            delete children[i];
        }
    }

    bool word(unsigned int k,unsigned int n,char res[N]) {
        int div = factorial(N-1,N-k+1);
        int i=n/div;
//        qDebug() << "n=" << n << " k=" << k << "div=" << div << " i=" << i << "res[0]=" << children[i]->letter;
        res[0]=children[i]->letter;
        if (k>1) {
           children[i]->word(k-1,n%div,1,res);
        }
        return true;
    }
};

#endif // PERMUTATION_H
