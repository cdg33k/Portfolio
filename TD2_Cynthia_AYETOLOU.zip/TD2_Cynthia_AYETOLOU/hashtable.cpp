#include "hashtable.h"

// Constructeur de HashTable
HashTable::HashTable(int p_size) : size(p_size), table(new MyList[p_size]) {}

// Destructeur de HashTable
HashTable::~HashTable() {
    delete[] table;
}

// Charge les mots dans la table de hachage
bool HashTable::loadFile(const QString &fileName) {
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return false;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (!line.isEmpty()) {
            int key = getKey(line);
            table[key].pushBack(line);
        }
    }
    file.close();
    return true;
}

// Recherche un mot dans la table de hachage
bool HashTable::find(const QString& word) {
    int key = getKey(word);
    return table[key].find(word) != nullptr;
}

// Constructeur de HashTableLetter
HashTableLetter::HashTableLetter(int p_size) : HashTable(p_size) {}

// Clé de hachage basée sur la lettre initiale
int HashTableLetter::getKey(const QString& word) const {
    return word[0].toUpper().unicode() - 'A';
}

// Constructeur de HashTableSum
HashTableSum::HashTableSum(int p_size) : HashTable(p_size) {}

// Clé de hachage basée sur la somme des valeurs ASCII
int HashTableSum::getKey(const QString& word) const {
    int sum = 0;
    for (int i = 0; i < word.size(); ++i) {
        sum += word[i].unicode();
    }
    return sum % size;
}
