#include "hashtable.h"
#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}

int main() {
    // Créer une table de hachage basée sur la lettre initiale
    HashTableLetter hashTableLetter(26);  // 26 cases pour les lettres A à Z
    hashTableLetter.loadFile("words5.txt");  // Charge les mots dans la table de hachage
    qDebug() << "Recherche 'Apple' dans HashTableLetter :" << hashTableLetter.find("Apple");

    // Créer une table de hachage basée sur la somme des valeurs ASCII
    HashTableSum hashTableSum(26);
    hashTableSum.loadFile("words5.txt");
    qDebug() << "Recherche 'Apple' dans HashTableSum :" << hashTableSum.find("Apple");

    if (hashTableLetter.loadFile("words5.txt")) {
        qDebug() << "Le fichier a été chargé avec succès dans HashTableLetter.";

        // Affiche la répartition des mots dans chaque sous-liste
        for (int i = 0; i < 26; ++i) {  // size vaut 26 dans ce cas pour A-Z
            qDebug() << "Sous-liste" << i << ": contient" << hashTableLetter.table[i].countIt() << "mots";
        }
    } else {
        qDebug() << "Erreur lors du chargement du fichier dans HashTableLetter.";
    }

    return 0;
}

