#include "mylist.h"
#include <QDebug>
#include <QFile>
#include <QTextStream>

// Implémentation des méthodes de MyList

void MyList::pushFront(const QString &newWord) {
    first = new Element(newWord, first);
}

void MyList::pushBack(const QString &newWord) {
    if (!first) {
        first = new Element(newWord);
    } else {
        Element *temp = first;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = new Element(newWord);
    }
}

Element* MyList::insert(const QString &newWord, Element* prev) {
    if (prev == nullptr) return nullptr;
    prev->next = new Element(newWord, prev->next);
    return prev->next;
}

Element* MyList::insertPlaced(const QString &newWord) {
    if (first == nullptr || first->word > newWord) {
        pushFront(newWord);
        return first;
    }

    Element* current = first;
    while (current->next != nullptr && current->next->word < newWord) {
        current = current->next;
    }

    if (current->word != newWord) {
        current->next = new Element(newWord);
    }
    return current->next;
}

Element* MyList::find(const QString &searched) {
    Element *temp = first;
    while (temp != nullptr) {
        if (temp->word == searched) {
            return temp;
        }
        temp = temp->next;
    }
    return nullptr;
}

void MyList::print() {
    Element *temp = first;
    while (temp != nullptr) {
        qDebug() << temp->word;
        temp = temp->next;
    }
}

void MyList::printRecursif() {
    if (first != nullptr) {
        first->printRecursif();
    }
}

bool MyList::loadFile(const QString &fileName) {
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Erreur : impossible d'ouvrir le fichier" << fileName;
        return false;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (!line.isEmpty()) {
            pushBack(line);
            qDebug() << "Mots lus dnas les fichiers" << line;  // Affiche chaque ligne dans la console
        }
    }
    file.close();
    return true;
}
