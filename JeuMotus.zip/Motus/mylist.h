#ifndef MYLIST_H
#define MYLIST_H

#include <QString>
#include <QFile>
#include <QTextStream>
#include <QDebug>

// Classe pour gérer un élément contenant un mot
// Un élément est un nœud de la liste chaînée, chaque élément contient un mot (QString) et un pointeur vers le prochain élément.
class Element {
public:
    QString word;     // Mot stocké dans cet élément de la liste
    Element *next;    // Pointeur vers le prochain élément de la liste

    // Constructeur qui initialise un élément avec un mot et le pointeur vers le prochain élément
    Element(const QString &p_word, Element *p_next = nullptr) :
        word(p_word), next(p_next) {}

    // Méthode récursive pour afficher les mots de la liste en partant de cet élément
    void printRecursif() {
        qDebug() << word;         // Affiche le mot courant
        if (next != nullptr) {     // Si un élément suivant existe, appelle récursivement la fonction sur le suivant
            next->printRecursif();
        }
    }

    // Destructeur qui supprime récursivement tous les éléments de la liste à partir de cet élément
    ~Element() {
        delete next; // Supprime le prochain élément, ce qui supprime récursivement tous les éléments suivants
    }
};

// Classe MyList pour gérer la liste chaînée d'éléments
class MyList {
    Element *first;  // Pointeur vers le premier élément de la liste

public:

    // Déclaration d'une structure Node utilisée pour une autre liste (pas utilisée ici dans les méthodes)
    struct Node {
        int value;     // Valeur de l'élément
        Node* next;    // Pointeur vers l'élément suivant
    };

    Node* head;   // Pointeur vers le début de la structure Node (pas utilisé dans les méthodes actuelles)

    // Constructeur par défaut qui initialise la liste comme vide
    MyList() : first(nullptr) {}

    // Destructeur qui supprime le premier élément, ce qui déclenche la suppression de tous les éléments de la liste
    ~MyList() { delete first; }

    // Méthode pour ajouter un mot au début de la liste
    void pushFront(const QString &newWord);

    // Méthode pour ajouter un mot à la fin de la liste
    void pushBack(const QString &newWord);

    // Méthode pour insérer un mot après un élément donné
    Element* insert(const QString &newWord, Element* prev);

    // Méthode pour insérer un mot dans l'ordre, en évitant les doublons
    Element* insertPlaced(const QString &newWord);

    // Méthode pour rechercher un mot dans la liste
    Element* find(const QString &searched);

    // Méthode pour rechercher un mot dans une liste triée (non utilisée ici)
    Element* findSorted(const QString &searched);

    // Méthode pour afficher tous les mots de la liste
    void print();

    // Méthode pour afficher tous les mots de la liste en appelant `printRecursif`
    void printRecursif();

    // Méthode pour charger les mots depuis un fichier et les ajouter à la liste
    bool loadFile(const QString &fileName);

    //mehtode pour les mots aleatoires                     // Imprimer tous les mots (déjà présent)
    QString getRandomWord() const;          // Récupérer un mot aléatoire (nouveau)





    // Méthode pour obtenir le premier élément de la liste
    Element* getFirst() const {
        return first;
    }

    // Méthode itérative pour compter les éléments de la liste
    // Utilise une boucle `while` pour parcourir chaque élément et compter les éléments
    int countIt() const {
        int count = 0;          // Initialise le compteur d'éléments
        Node* current = head;    // Commence à partir du premier élément de la liste

        while (current != nullptr) {   // Tant qu'il y a un élément dans la liste
            count++;                   // Incrémente le compteur
            current = current->next;   // Passe à l'élément suivant
        }

        return count; // Retourne le nombre total d'éléments
    }

    // Méthode récursive pour compter les éléments de la liste
    // Appelle la fonction auxiliaire `countRecHelper` en lui passant le premier élément
    int countRec() const {
        return countRecHelper(first);  // Appel de la fonction récursive auxiliaire pour compter les éléments
    }

    // Fonction auxiliaire de `countRec`, qui compte récursivement les éléments de la liste
    int countRecHelper(Element* current) const {
        if (current == nullptr) {      // Condition de fin de récursion : si la liste est vide
            return 0;                  // Retourne 0 si aucun élément n'est trouvé
        } else {
            return 1 + countRecHelper(current->next);  // Compte l'élément courant et appelle récursivement pour l'élément suivant
        }
    }
};

#endif // MYLIST_H
