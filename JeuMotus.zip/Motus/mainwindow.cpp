#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    if (!lstWord7.loadFile("../../words7.txt")) { // charger le fichier des mots de 7 lettres
        QMessageBox::critical(this, "Erreur", "Impossible de charger le fichier de mots !");
    }
    else {
        // Définir un mot cible pour le Canvas
        ui->widget->setTargetWordFromList(lstWord7);
    }
}



MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_reglesJeu_triggered()
{
    QMessageBox::information(this, "Règles du jeu",
                             "Règles du jeu :\n"
                             "1-  Sélectionnez des lettres pour former un mot.\n"
                             "2- Validez votre mot en cliquant sur Valider.\n"
                             "3- Les couleurs indiquent :\n"
                             "  * Vert : Lettre correcte et bien placée.\n"
                             "  * Orange : Lettre correcte mais mal placée.\n"
                             "  * Rouge : Lettre absente.\n"
                             "4- Vous avez 5 tentatives pour trouver le mot.\n\n"
                              "NB : une lettre sélectionnée ne peut être changée.\n"
                             "Bonne chance !");
}


void MainWindow::on_pushButton_clicked() // pour le bouton recommencer
{
    ui->widget->setTargetWordFromList(lstWord7); // Définir un nouveau mot cible
     ui->widget->restartGame();
}


void MainWindow::on_pushButton_2_clicked() // pour le bouton valider
{
    ui->widget->validateWord();
}


void MainWindow::on_pushButton_3_clicked() // pour le bouton quitter
{
    // Afficher une boîte de dialogue pour confirmer la fermeture
    QMessageBox::StandardButton reply = QMessageBox::question(
        this, "Quitter", "Voulez-vous vraiment quitter le jeu ?",
        QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        QApplication::quit();
    }
}

