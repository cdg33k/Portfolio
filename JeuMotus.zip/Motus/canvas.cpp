#include "canvas.h"
#include <QGridLayout>
#include <QMessageBox>
#include <QPainter>
#include<mylist.h>

Canvas::Canvas(QWidget *parent)
    : QWidget(parent), attemptsLeft(5) {

// jai préféré ajouter certains élement avec le code car au fur et à mesure jai de nouvelles idees et ca devient plus difficile pour moi
// de tout bouger à chaque fois sur le ui

    // Ici, je configure tout ce qui est lié au jeu

    QVBoxLayout *mainLayout = new QVBoxLayout(this); // Layout principal pour tous les elmeents

    // Layout pour les 7 lettres
    QHBoxLayout *lettersLayout = new QHBoxLayout();


    // Je crée des labels pour afficher les 7 lettres choisis

    for (int i = 0; i < 7; ++i) {
        QLabel *label = new QLabel("-", this);
        label->setAlignment(Qt::AlignCenter);
        label->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);  // Défini une politique de taille expansible
        label->setMinimumSize(50, 50);  // Définir une taille minimum pour le label (pour éviter qu'il devienne trop petit)

        QFont font("Arial", 22); // Appliquer le style pour agrandir la police des lettres
        letterDisplays.push_back(label);
        lettersLayout->addWidget(label);
    }
    mainLayout->addStretch(2); // Espace au-dessus des lettres
    mainLayout->addLayout(lettersLayout); // Ajouter le layout des lettres au layout principal
    mainLayout->addStretch(1); // Espace  en dessous des lettres

    // Maintenant, je vais ajouter automatiquement les boutons pour chaque lettre de l'alphabet

    // === Layout pour les boutons de l'alphabet ===
    QGridLayout *alphabetLayout = new QGridLayout();
    QString alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    for (int i = 0; i < 26; ++i) {
        QPushButton *button = new QPushButton(QString(alphabet[i]), this);
        button->setStyleSheet("font-size: 16px; min-width: 50px; min-height: 50px; font-weight : bold");
        connect(button, &QPushButton::clicked, this, &Canvas::handleLetterButton);
        letterButtons.push_back(button);
        alphabetLayout->addWidget(button, i / 13, i % 13); // Organiser en deux lignes
    }
    mainLayout->addLayout(alphabetLayout);
    mainLayout->addStretch(1);

}

// methode qui defini le mot target a deviner
void Canvas::setTargetWord(const QString &word) {
    targetWord = word.trimmed().toUpper(); // Nettoie et met en majuscules
    qDebug() << "Mot cible défini :" << targetWord; // Debug : Affiche le mot cible
    resetGame();
}

// methode qui fedini le mot choisi au hasard
void Canvas::setTargetWordFromList(MyList &wordList) {
    QString randomWord = wordList.getRandomWord();
    if (!randomWord.isEmpty()) {
        setTargetWord(randomWord); // Réutilisation de setTargetWord defini plus haut
    } else {
        QMessageBox::warning(this, "Erreur", "La liste des mots est vide !");
    }
}

// pour reinitialiser le jeu
void Canvas::resetGame() {
    currentGuess.clear();
    attemptsLeft = 5;

    for (auto label : letterDisplays) {
        label->setText("-");
        label->setStyleSheet("font-size: 18px; border: 1px solid black;");
    }

    for (auto button : letterButtons) {
        button->setEnabled(true);
        button->setStyleSheet("");
    }

    updateAttemptsDisplay(); // Mettre à jour l'affichage des tentatives restantes
}

// methode pour afficher les lettres choisies au mot
void Canvas::handleLetterButton() {
    // ici je récupère la lettre cliquée et je l'ajoute à mon mot en cours
    QPushButton *button = qobject_cast<QPushButton *>(sender());
    if (!button || currentGuess.length() >= 7) return;

    currentGuess += button->text();
    for (int i = 0; i < currentGuess.length(); ++i) {
        letterDisplays[i]->setText(QString(currentGuess[i]));
        letterDisplays[i]->setStyleSheet("font-weight: bold; color: black; border: 1px solid black;");        // Noir et gras pour les lettres sélectionnées
        button->setStyleSheet("background-color: yellow; color: black;"); // lorsquune lettre de l'alphabet est cliquée le boutton devient jaune
    }

    updateDisplay();
}
 // Cette fonction met à jour les labels avec les lettres choisies
void Canvas::updateDisplay() {
    for (int i = 0; i < 7; ++i) {
        if (i < currentGuess.length()) {
            letterDisplays[i]->setText(QString(currentGuess[i]));
        } else {
            letterDisplays[i]->setText("-");
        }
    }
}

// Réinitialisez l'affichage des lettres choisies
void Canvas::clearGuess() {
    currentGuess.clear();
    for (auto label : letterDisplays) {
        label->setText("-");
    }
}


//fonction pour valider le mot (lorsqu'on clique sur le bouton valider)
void Canvas::validateWord() {
    // Vérifie que le mot deviné a exactement 7 lettres (controle mis quand javais des erreurs)
    if (currentGuess.length() != 7) {
        QMessageBox::warning(this, "Erreur", "Vous devez sélectionner 7 lettres.");
        return;
    }

    // Vérifie si le mot cible est vide
    if (targetWord.isEmpty() ) {
        QMessageBox::critical(this, "Erreur", "Le mot cible est vide !");
        return;
    }
    qDebug() << "currentGuess:" << currentGuess << "targetWord:" << targetWord;

    // Vérifiez si le joueur a deviné le mot correctement
    if (currentGuess == targetWord) {
        for (size_t i = 0; i < letterDisplays.size(); ++i) {
            letterDisplays[i]->setText(QString(currentGuess[i])); // Afficher la lettre
            letterDisplays[i]->setStyleSheet("background-color: green; color: white; font-weight: bold;"); // Mettre en vert
        }
        QMessageBox::information(this, "Félicitations", "Quel génie ! Vous avez trouvé le mot : " + targetWord);
        return; // Sortir de la fonction pour éviter de réduire les tentatives
    }

    checkGuess(); // Vérifie les lettres devinées
    currentGuess.clear(); // Réinitialiser l'essai en cours
    // Décrémente le nombre de tentatives restantes
    if (attemptsLeft > 0) {
        --attemptsLeft;
        updateAttemptsDisplay(); // Mettre à jour les tentatives restantes
    }
    else {
        QMessageBox::information(this, "Perdu", "Vous avez épuisé vos tentatives ! Appuyez sur recommencer pour un nouveau jeu. Le mot était : " + targetWord  );
    }
}

// verifier les lettres entrées
void Canvas::checkGuess() {

    for (int i = 0; i < currentGuess.length(); ++i) {
        if (i >= targetWord.length()) {
            qDebug() << "Erreur : Index " << i << " hors des limites de targetWord.";
            return;
        }
        for (size_t i = 0; i < letterDisplays.size(); ++i) {
            if (targetWord[i] == currentGuess[i]) {
                // Lettre correcte et bien placée (en vert)
                letterDisplays[i]->setText(QString(currentGuess[i]));
                letterDisplays[i]->setStyleSheet("background-color: green; color: white; font-weight: bold;");
            } else if (targetWord.contains(currentGuess[i])) {
                // Lettre correcte mais mal placée (en orange)
                letterDisplays[i]->setText(QString(currentGuess[i])); //  afficher la lettre
                letterDisplays[i]->setStyleSheet("background-color: orange; color: white; ");
            } else {
                // Lettre absente (en rouge)
                letterDisplays[i]->setText(QString(currentGuess[i])); // afficher la lettre
                letterDisplays[i]->setStyleSheet("background-color: red; color: white;");
            }
        }

        qDebug() << "i:" << i << "targetWord[i]:" << targetWord[i] << "currentGuess[i]:" << currentGuess[i];

    }
}

// met à jour les tentatives restantes
void Canvas::updateAttemptsDisplay() {
    QLabel *attemptsLabel = findChild<QLabel *>("attemptsLabel");\
        attemptsLabel->setStyleSheet("color: black; font-size: 16px;");
    if (attemptsLabel) {
        attemptsLabel->setText("Tentatives restantes : " + QString::number(attemptsLeft));
    }
}

// pour le rendu visuel
void Canvas::paintEvent(QPaintEvent *) {
    QPainter painter(this);

    // fond bleu clair
    painter.fillRect(rect(), QColor(173, 200, 255));

    // Afficher le message d'accueil
    QString rulesHeader = "Bienvenue !";

    QFont headerFont("Arial", 14, QFont::Bold);
    painter.setFont(headerFont);
    painter.setPen(Qt::black); // message en noir

    QRect headerRect(10, 50, width() - 20, 30);
    painter.drawText(headerRect, Qt::AlignHCenter | Qt::AlignTop, rulesHeader);

    // Afficher les instructions
    QFont italicFont("Arial", 12);
    italicFont.setItalic(true);
    painter.setFont(italicFont);

    QRect instructionsRect(10, headerRect.bottom() + 5, width() - 20, 50);
    painter.drawText(instructionsRect, Qt::AlignHCenter | Qt::AlignTop,
                     "Cliquez sur _A Propos_ pour voir les règles du jeu.\n\nBonne chance !");
}

// restart game appelle reset game ( je crois que j'aurais pu m'en passer)
void Canvas::restartGame() {
    resetGame();
}
