#include "mylist.h"
#include <QDebug>
#include <QFile>
#include <QTextStream>
#include <cstdlib>
#include <ctime>

// Implémentation des méthodes de MyList ( pas tous utiles pour cet execice mais je les garde vuq ue jai pris la base sur le TD2)

void MyList::pushFront(const QString &newWord) {
    first = new Element(newWord, first);
}

void MyList::pushBack(const QString &newWord) {
    if (!first) {
        first = new Element(newWord);
    } else {
        Element *temp = first;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = new Element(newWord);
    }
}

Element* MyList::insert(const QString &newWord, Element* prev) {
    if (prev == nullptr) return nullptr;
    prev->next = new Element(newWord, prev->next);
    return prev->next;
}

Element* MyList::insertPlaced(const QString &newWord) {
    if (first == nullptr || first->word > newWord) {
        pushFront(newWord);
        return first;
    }

    Element* current = first;
    while (current->next != nullptr && current->next->word < newWord) {
        current = current->next;
    }

    if (current->word != newWord) {
        current->next = new Element(newWord);
    }
    return current->next;
}

Element* MyList::find(const QString &searched) {
    Element *temp = first;
    while (temp != nullptr) {
        if (temp->word == searched) {
            return temp;
        }
        temp = temp->next;
    }
    return nullptr;
}

void MyList::print() {
    Element *temp = first;
    while (temp != nullptr) {
        qDebug() << temp->word;
        temp = temp->next;
    }
}

void MyList::printRecursif() {
    if (first != nullptr) {
        first->printRecursif();
    }
}

bool MyList::loadFile(const QString &fileName) {
    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Erreur : impossible d'ouvrir le fichier" << fileName;
        return false;
    }

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();

        if (!line.isEmpty()) {
            pushBack(line);
            //qDebug() << "fichier chargé avec succes" << line; // Affiche chaque ligne dans la console (pour etre sur que les mots sont là)
        }
    }

    qDebug() << "fichier chargé avec succes";
    file.close();
    return true;
}


QString MyList::getRandomWord() const {
    if (!first) {
        return ""; // Retourner une chaîne vide si la liste est vide
    }

    // Compter le nombre d'éléments dans la liste
    int count = 0;
    Element *temp = first;
    while (temp != nullptr) {
        ++count;
        temp = temp->next;
    }

    // Générer un index aléatoire
    srand(static_cast<unsigned>(time(nullptr)));
    int randomIndex = rand() % count;

    // Récupérer l'élément à cet index
    temp = first;
    for (int i = 0; i < randomIndex; ++i) {
        temp = temp->next;
    }

    return temp->word; // Retourner le mot
}
