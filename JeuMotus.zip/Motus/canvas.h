#ifndef CANVAS_H
#define CANVAS_H

#include <QWidget>
#include <QPainter>
#include <QPushButton>
#include <QPaintEvent>
#include <QLabel>
#include <QString>
#include <vector>
#include <mylist.h>


class Canvas : public QWidget {
    Q_OBJECT

public:
    explicit Canvas( QWidget *parent = nullptr);

    void setTargetWord(const QString &word); // Ici je  définis le mot cible
    void resetGame();                        // Réinitialise tout le jeu
    void setTargetWordFromList(MyList &wordList); // Définit un mot depuis la liste

public slots:
    void handleLetterButton(); // Cette fonction est appelée quand je clique sur une lettre
    void validateWord();       // Fonction pour valider mon mot
    void restartGame();        // Fonction pour recommencer une partie

protected:
    void paintEvent(QPaintEvent *event) override; // pain event pour gérer l'affichage graphique

private:
    QString targetWord;       // Le mot à deviner
    QString currentGuess;     // Mon essai en cours
    int attemptsLeft;         // Nombre de tentatives restantes
    std::vector<QPushButton *> letterButtons; // Les boutons des lettres de l'alphabet
    std::vector<QLabel *> letterDisplays;     // Les labels pour afficher mes choix

    void updateDisplay(); // Met à jour les lettres que j'ai choisies
    void checkGuess();    // Vérifie si mon mot est correct
    void clearGuess();    // Réinitialise uniquement l'essai en cours
    void updateAttemptsDisplay(); // Met à jour le décompte des tentatives
};

#endif // CANVAS_H

