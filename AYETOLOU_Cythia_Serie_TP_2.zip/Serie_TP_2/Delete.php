<?php
include 'connect.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer le matricule
    $matricule = $_POST['matricule'];

    //requête SQL
    $sql = "DELETE FROM Etudiant WHERE matricule='$matricule'";

    echo "<div class='container'>";
    if ($conn->query($sql) === TRUE) {
        echo "<p class='success'>L'étudiant ayant le matricule <strong>$matricule</strong> a été supprimé avec succès.</p>";
        echo "<a class='button' href='Lister.php'>Voir la liste des étudiants</a>";
    } else {
        echo "<p class='error'>Erreur : " . $conn->error . "</p>";
    }
    echo "</div>";
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suppression Étudiant</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; text-align: center; }
        .container { background: white; padding: 20px; border-radius: 5px; box-shadow: 0px 0px 10px #ccc; max-width: 400px; margin: auto; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .button { display: inline-block; background-color: green; color: white; padding: 10px; margin-top: 10px; text-decoration: none; border-radius: 5px; }
        .button:hover { opacity: 0.8; }
    </style>
</head>
<body>
</body>
</html>
