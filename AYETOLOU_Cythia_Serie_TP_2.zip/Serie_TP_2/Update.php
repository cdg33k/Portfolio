<?php
include 'connect.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer les données du formulaire
    $matricule = $_POST['matricule'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $adresse = $_POST['adresse'];
    $date_naissance = $_POST['date_naissance'];
    $email = $_POST['email'];
    $filiere = $_POST['filiere'];

    //  exécuter la requête SQL
    $sql = "UPDATE Etudiant 
            SET nom='$nom', prenom='$prenom', adresse='$adresse', date_naissance='$date_naissance', email='$email', filiere='$filiere'
            WHERE matricule='$matricule'";

    echo "<div class='container'>";
    if ($conn->query($sql) === TRUE) {
        echo "<p class='success'>Bonjour cher Étudiant <strong>$nom $prenom</strong>, ayant le matricule <strong>$matricule</strong>, tes informations ont été modifiées.</p>";
        echo "<a class='button' href='Lister.php'>Voir la liste des étudiants</a>";
    } else {
        echo "<p class='error'>Erreur : " . $conn->error . "</p>";
    }
    echo "</div>";
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modification Étudiant</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; text-align: center; }
        .container { background: white; padding: 20px; border-radius: 5px; box-shadow: 0px 0px 10px #ccc; max-width: 400px; margin: auto; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .button { display: inline-block; background-color: green; color: white; padding: 10px; margin-top: 10px; text-decoration: none; border-radius: 5px; }
        .button:hover { opacity: 0.8; }
    </style>
</head>
<body>
</body>
</html>
