-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mar. 04 fév. 2025 à 20:21
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `db_connect`
--

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

CREATE TABLE `etudiant` (
  `matricule` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `nom` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `prenom` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `adresse` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `date_naissance` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `filiere` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`matricule`, `nom`, `prenom`, `adresse`, `date_naissance`, `email`, `filiere`) VALUES
('00987612', 'Ayetolou', 'Cynthia', 'RAS', '2025-01-08', 'cynthiayetolou@gmail.com', 'Informatique'),
('0900744', 'ADAMOU', 'Ramielle', 'tankpe', '2025-01-16', 'an@gmail.com', 'Informatique'),
('0900746', 'ADAMOU', 'Ramielle', 'tankpe', '2025-01-22', 'an@gmail.com', 'Informatique'),
('0900747', 'ADAMOU', 'Ramielle', 'tankpe', '2025-01-22', 'an@gmail.com', 'Informatique'),
('0900770', 'ADAMOU', 'Ramiel', 'tankpe', '0000-00-00', 'an@gmail.com', 'Informatique'),
('09008888', 'ADAMOU', 'Ramiel', 'tankpe', '0000-00-00', 'an@gmail.com', 'Informatique'),
('090088999', 'ADAMOU', 'Ramiel', 'tankpe', '0000-00-00', 'an@gmail.com', 'Informatique'),
('0955744', 'ogubiyi', 'antoine', 'tankep', '2025-01-22', 'an@gmail.com', 'Informatique');

-- --------------------------------------------------------

--
-- Structure de la table `filiere`
--

CREATE TABLE `filiere` (
  `nomF` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `filiere`
--

INSERT INTO `filiere` (`nomF`, `description`) VALUES
('Informatique', 'Étude des systèmes informatiques et du développement logiciel.'),
('Mathématiques', 'Étude des mathématiques fondamentales et appliquées.'),
('Physique', 'Étude des lois fondamentales de la nature.');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD PRIMARY KEY (`matricule`),
  ADD KEY `fk_filiere` (`filiere`);

--
-- Index pour la table `filiere`
--
ALTER TABLE `filiere`
  ADD PRIMARY KEY (`nomF`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD CONSTRAINT `fk_filiere` FOREIGN KEY (`filiere`) REFERENCES `filiere` (`nomF`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
