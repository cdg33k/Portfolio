<?php
// Informations de connexion à la base de données
$host = 'localhost'; 
$user = 'root'; 
$password = ''; 
$dbname = 'db_connect'; 

// Création de la connexion
$conn = new mysqli($host, $user, $password, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die('Erreur de connexion : ' . $conn->connect_error);
}

// Si tout va bien
echo "<div id='success-message'>Connexion réussie à la base de données</div>";
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <style>
        #success-message {
            color: green;
            font-weight: bold;
            text-align: center;
            margin-top: 20px;
        }
    </style>
    <script>
        setTimeout(function() {
            var message = document.getElementById("success-message");
            if (message) {
                message.style.display = "none";
            }
        }, 3000); // Pour que le message disparaît après 3 secondes au lieu d'etre présent sur toutes les pages
    </script>
</head>
<body>

</body>
</html>
