<?php

include 'connect.php'; 
// Récupérer les étudiants
$sql = "SELECT * FROM Etudiant";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Étudiants</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        h1 { color: #333; }
        table { width: 100%; border-collapse: collapse; background: white; box-shadow: 0px 0px 10px #ccc; }
        th, td { border: 1px solid black; padding: 10px; text-align: left; }
        th { background-color: #ddd; }
        button { background-color: green; color: white; padding: 10px; border: none; cursor: pointer; margin-top: 10px; }
        button:hover { opacity: 0.8; }
    </style>
</head>
<body>
    <h1>Liste des étudiants</h1>
    
    <?php if ($result->num_rows > 0) { ?>
        <table>
            <tr>
                <th>Matricule</th>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Adresse</th>
                <th>Date de Naissance</th>
                <th>Email</th>
                <th>Filière</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?= $row['matricule'] ?></td>
                    <td><?= $row['nom'] ?></td>
                    <td><?= $row['prenom'] ?></td>
                    <td><?= $row['adresse'] ?></td>
                    <td><?= $row['date_naissance'] ?></td>
                    <td><?= $row['email'] ?></td>
                    <td><?= $row['filiere'] ?></td>
                </tr>
            <?php } ?>
        </table>
    <?php } else { ?>
        <p>Aucun étudiant trouvé.</p>
    <?php } ?>

    <br>
    <a href="FormulaireEtudiant.php">
        <button type="button">Retour</button>
    </a>
</body>
</html>

<?php $conn->close(); ?>
