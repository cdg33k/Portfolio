<?php

include 'connect.php'; 

// Récupération des filières depuis la base de données
$sql = "SELECT NomF FROM Filiere";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $filiereOptions = '';
    while ($row = $result->fetch_assoc()) {
        $filiereOptions .= "<option value='{$row['NomF']}'>{$row['NomF']}</option>";
    }
} else {
    $filiereOptions = '<option value="">Aucune filière disponible</option>';
}
?> 

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Étudiants</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; }
        h1 { color: #333; text-align: center; }
        form { background: white; padding: 20px; border-radius: 5px; box-shadow: 0px 0px 10px #ccc; max-width: 400px; margin: auto; }
        label { font-weight: bold; display: block; margin-top: 10px; }
        input, select { width: 100%; padding: 8px; margin-top: 5px; border: 1px solid #ccc; border-radius: 5px; }
        button { background-color: green; color: white; padding: 10px; border: none; cursor: pointer; margin-top: 10px; }
        button:hover { opacity: 0.8; }
    </style>
</head>
<body>
    <h1>Formulaire de Gestion des Étudiants</h1>
    <form action="Add.php" method="post">
        <label for="matricule">Matricule :</label>
        <input type="text" id="matricule" name="matricule" required><br>

        <label for="nom">Nom :</label>
        <input type="text" id="nom" name="nom" required><br>

        <label for="prenom">Prénom :</label>
        <input type="text" id="prenom" name="prenom" required><br>

        <label for="adresse">Adresse :</label>
        <input type="text" id="adresse" name="adresse"><br>

        <label for="date_naissance">Date de Naissance :</label>
        <input type="date" id="date_naissance" name="date_naissance"><br>

        <label for="email">Email :</label>
        <input type="email" id="email" name="email"><br>

        <label for="filiere">Filière :</label>
        <select id="filiere" name="filiere">
            <?= $filiereOptions ?>
        </select><br>

        <button type="submit" formaction="Add.php">Add</button>
        <button type="submit" formaction="Update.php">Update</button>
        <button type="submit" formaction="Delete.php">Delete</button>
        <button type="button" onclick="window.location.href='Lister.php'">Select</button>
    </form>
</body>
</html>
