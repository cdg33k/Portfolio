<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$error = ""; // Message d'erreur

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    include 'db.php';
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Vérifier si l'utilisateur existe
    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Vérifier le mot de passe
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];

            // Redirection vers la page d'accueil
            header("Location: index.php");
            exit();
        } else {
            $error = "Mot de passe incorrect.";
        }
    } else {
        $error = "Aucun compte trouvé avec cet email.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; text-align: center; }
        .container { background: white; padding: 20px; border-radius: 5px; box-shadow: 0px 0px 10px #ccc; max-width: 400px; margin: auto; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .button { display: inline-block; background-color: green; color: white; padding: 10px; margin-top: 10px; text-decoration: none; border-radius: 5px; }
        .button:hover { opacity: 0.8; }
        .form-group {
    display: flex;
    align-items: center; 
    justify-content: space-between; 
    margin-bottom: 15px; 
}

.form-group label {
    width: 30%;
    font-weight: bold;
    text-align: left;
}

.form-group input {
    width: 65%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

    </style>
</head>
<body>
    <div class="container">
        <h1>Connexion</h1>

        <!-- Message après déconnexion -->
        <?php if (isset($_GET['logout']) && $_GET['logout'] == 'success') { ?>
            <p class="success">Vous avez été déconnecté avec succès.</p>
        <?php } ?>

        <!-- Affichage des erreurs de connexion -->
        <?php if (!empty($error)) { ?>
            <p class="error"><?= $error ?></p>
        <?php } ?>

        <form action="login.php" method="POST">
    <div class="form-group">
        <label>Email:</label>
        <input type="email" name="email" required>
    </div>

    <div class="form-group">
        <label>Mot de passe:</label>
        <input type="password" name="password" required>
    </div>

    <button type="submit" class="button">Se connecter</button>
</form>
<p>Pas encore inscrit ? <a href="register.php">Créer un compte</a></p>

    </div>
</body>
</html>
