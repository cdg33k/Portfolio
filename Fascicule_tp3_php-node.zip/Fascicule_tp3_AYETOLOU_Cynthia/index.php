<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username']; // Récupérer le nom d'utilisateur
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; text-align: center; }
        .container { background: white; padding: 20px; border-radius: 5px; box-shadow: 0px 0px 10px #ccc; max-width: 400px; margin: auto; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .button { display: inline-block; background-color: green; color: white; padding: 10px; margin-top: 10px; text-decoration: none; border-radius: 5px; }
        .button:hover { opacity: 0.8; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Bienvenue, <?= htmlspecialchars($username); ?> !</h1>
        <p>Vous êtes connecté.</p>
        <a class="button" href="logout.php">Se déconnecter</a>
    </div>
</body>
</html>
