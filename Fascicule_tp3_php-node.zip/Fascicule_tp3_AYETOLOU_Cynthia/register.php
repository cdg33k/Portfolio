<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    include 'db.php';
    $username = $_POST['username'];
    $first_name = $_POST['first_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $date_of_birth = $_POST['date_of_birth'];

    // Vérifier si l'email est déjà utilisé
    $checkEmail = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $result = $checkEmail->get_result();

    if ($result->num_rows > 0) {
        $error = "Cet email est déjà utilisé.";
    } else {
        // Hachage du mot de passe
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insérer l'utilisateur
        $stmt = $conn->prepare("INSERT INTO users (username, first_name, email, password, date_of_birth) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $username, $first_name, $email, $hashed_password, $date_of_birth);

        if ($stmt->execute()) {
            $success = "Inscription réussie ! <a href='login.php'>Connectez-vous</a>";
        } else {
            $error = "Erreur lors de l'inscription.";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; text-align: center; }
        .container { background: white; padding: 20px; border-radius: 5px; box-shadow: 0px 0px 10px #ccc; max-width: 400px; margin: auto; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .button { display: inline-block; background-color: green; color: white; padding: 10px; margin-top: 10px; text-decoration: none; border-radius: 5px; }
        .button:hover { opacity: 0.8; }
        .form-group {
    display: flex;
    align-items: center;
    justify-content: space-between; 
    margin-bottom: 15px; 
}

.form-group label {
    width: 30%;
    font-weight: bold;
    text-align: left;
}

.form-group input, 
.form-group select {
    width: 65%; 
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
}



    </style>
</head>
<body>
    <div class="container">
        <h1>Inscription</h1>
        <?php if (!empty($error)) { ?>
    <p class="error"><?= $error ?></p>
<?php } ?>
<?php if (!empty($success)) { ?>
    <p class="success"><?= $success ?></p>
<?php } ?>

<div class="form-group">
    <label>Nom d'utilisateur:</label>
    <input type="text" name="username" required>
</div>

<div class="form-group">
    <label>Prénom:</label>
    <input type="text" name="first_name" required>
</div>

<div class="form-group">
    <label>Email:</label>
    <input type="email" name="email" required>
</div>

<div class="form-group">
    <label>Mot de passe:</label>
    <input type="password" name="password" required>
</div>

<div class="form-group">
    <label>Date de naissance:</label>
    <input type="date" name="date_of_birth" required>
</div>

<button type="submit" class="button">S'inscrire</button>

        <p>Déjà inscrit ? <a href="login.php">Connectez-vous</a></p>
        
    </div>
</body>
</html>


