<?php
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'users';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("<div class='error'>Erreur de connexion : " . $conn->connect_error . "</div>");
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion Base de Données</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; text-align: center; }
        .error { color: red; font-weight: bold; }
        .success { color: green; font-weight: bold; }
    </style>
</head>
<body>
</body>
</html>
