<?php
//EXERICE 10
echo "<h1>Table d'addition</h1>";
echo "<table border= 1'>";
echo "<tr style='border: 1px solid ;'>"; 
for ($i = 1; $i <= 9; $i++) {
    $j = 10 - $i;
    echo "<td style='border: 1px solid ;'>$i + $j = 10</td>";
}

echo "</tr>"; 
echo "</table>"; 
?>
