<?php
$personnes = [
    "Dupont" => [
        "prénom" => "Paul",
        "ville" => "Paris",
        "âge" => 27
    ],
    "Schmoll" => [
        "prénom" => "Kirk",
        "ville" => "Berlin",
        "âge" => 35
    ],
    "Smith" => [
        "prénom" => "Stan",
        "ville" => "Londres",
        "âge" => 45
    ]
];

// Affichage de la structure complète du tableau
echo "<h3>Structure complète du tableau :</h3>";
echo "<pre>";
print_r($personnes);
echo "</pre>";
?>
