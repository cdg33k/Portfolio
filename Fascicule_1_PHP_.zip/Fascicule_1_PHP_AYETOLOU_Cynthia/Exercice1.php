<?php
//Exercice 1

echo "Bienvenue à L’UFR STGI - université de Franche-Comté! <br>"    ; 
echo 'Ceci est une ligne créée uniquement en PHP <br>';
echo ' Ceci est la 2ème phrase créée avec PHP <br> ';
echo '<a href="https://stgi.univ-fcomte.fr/" target="_blank">Visitez le site de l\'UFR STGI</a> <br> <br>';

?>