<?php
// Liste des variables à tester
$variables = [
    'mavar',
    '$mavar',
    '$var5',
    '$_mavar',
    '$_5var',
    '$__élément1',
    '$hotel4*'
];

// affichage des résultats
echo "<h3>Parmi les variables suivantes lesquelles sont valides ? <br></h3>";
foreach ($variables as $var) {
    
    if (preg_match('/^\$[a-zA-Z_\x80-\xff][a-zA-Z0-9_\x80-\xff]*$/', $var)) {
        echo "$var : Valide<br>";
    } else {
        echo "$var : Non valide<br>";
    }
}
?>
