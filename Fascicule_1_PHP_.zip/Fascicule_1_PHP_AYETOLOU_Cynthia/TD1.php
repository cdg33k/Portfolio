<?php
// erxercice 1

echo "bienvenu à L’UFR STGI - université de Franche-Comté, <br>"    ; 
echo 'Ceci est une ligne créée uniquement en PHP <br>';
echo ' Ceci est la 2ème phrase créée avec PHP <br> ';
echo '<a href="https://stgi.univ-fcomte.fr/" target="_blank">Visitez le site de l\'UFR STGI</a> <br> <br>';



//Exercice 2
$nom = "Jarray";
$prenom = "Ridha";

// Affichage avec 2 commandes echo
echo $nom;
echo " ";
echo $prenom;
echo "<br>";

echo "$nom $prenom<br>";

echo $nom . " " . $prenom;

?>