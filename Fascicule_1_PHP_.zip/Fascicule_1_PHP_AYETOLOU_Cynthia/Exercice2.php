<?php

//Exercice 2
$nom = "Ayetolou";
$prenom = "Cynthia";

// Affichage avec 2 commandes echo
echo $nom;
echo " ";
echo $prenom;
echo "<br>";

// Affichage avec une seule commande echo 
echo "$nom $prenom<br>";

// Affichage avec une commande echo avec le point de concatenation
echo $nom . " " . $prenom;

?>