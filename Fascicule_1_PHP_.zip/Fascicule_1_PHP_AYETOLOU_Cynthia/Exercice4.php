<?php
echo "<h1>Calcul et comparaison des prix</h1>";

$prix_table = 150;
$prix_armoire = 50;
$Nombre = 10;

$prix_total_armoire = $prix_armoire * $Nombre;
echo "Le prix HT total pour 10 armoires est :  $prix_total_armoire € <br>";

if ( $prix_armoire>$prix_table )
 {
    echo "L'armoire est plus chere que la table <br>";
 }
 elseif ($prix_armoire < $prix_table)
 {
    echo "Le prix de la table (150 €) est plus eleve que l'armoire (50€)";
 }
 else { echo "La table et l'armoire ont le meme prix" ;}

?>