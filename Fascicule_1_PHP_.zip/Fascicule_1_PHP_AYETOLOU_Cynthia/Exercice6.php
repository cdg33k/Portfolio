

<?php

echo "<h2>Triangle rectangle avec des caractères *</h2>";

// Définir la taille du triangle
$taille = 5; // Vous pouvez modifier la taille ici

// Boucle pour afficher le triangle
for ($i = 1; $i <= $taille; $i++) {
    // Affiche $i étoiles
    echo str_repeat("*", $i) . "<br>";
}
?>
