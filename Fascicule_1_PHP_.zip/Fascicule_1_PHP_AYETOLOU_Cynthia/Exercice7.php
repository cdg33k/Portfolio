<?php

echo "<h1>Division</h1>";

$x = 10;
$y = 2.0;


if ($y != 0) {
    $resultat = $x / $y;
    echo "Résultat de la division : $x ÷ $y = $resultat<br>";
} else {
    echo "Erreur : Division par zéro impossible.<br>";
}



?>