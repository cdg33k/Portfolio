<?php
$personnes = [
    "Dupont" => [
        "prénom" => "Paul",
        "ville" => "Paris",
        "âge" => 27
    ],
    "Schmoll" => [
        "prénom" => "Kirk",
        "ville" => "Berlin",
        "âge" => 35
    ],
    "Smith" => [
        "prénom" => "Stan",
        "ville" => "Londres",
        "âge" => 45
    ]
];

// Parcours et affichage des informations
foreach ($personnes as $nom => $infos) {
    echo "<b>Nom :</b> $nom<br>";
    echo "<b>Prénom :</b> " . $infos['prénom'] . "<br>";
    echo "<b>Ville :</b> " . $infos['ville'] . "<br>";
    echo "<b>Âge :</b> " . $infos['âge'] . " ans<br><br>";
}
?>
