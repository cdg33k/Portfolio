<?php

echo "<h1>Calcul de la somme des entiers de 1 à n </h1>";
// Initialisation de la variable
$nbre = 1280; 
$somme = 0;

// Calcul de la somme avec FOR
for ($i = 1; $i <= $nbre; $i++) {
    $somme += $i;
}
echo "La somme des entiers de 1 à $nbre avec FOR: $somme<br>";

// Réinitialisation pour la boucle WHILE
$somme = 0;
$i = 1;

// Calcul de la somme avec WHILE
while ($i <= $nbre) {
    $somme += $i;
    $i++;
}
echo "La somme des entiers de 1 à $nbre avec WHILE= : $somme<br>";
?>
