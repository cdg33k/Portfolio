<?php
// Affichage du titre
echo "<h1>Calcul sur les variables</h1>";

// Déclaration et initialisation des variables
$TVA = 0.206;
$prix = 150;
$Nombre = 10;

// Calcul des prix
$prixHT = $prix * $Nombre;
$prixTTC = $prixHT * (1 + $TVA);

echo "Prix HT pour $Nombre articles est: $prixHT €<br>";
echo "Prix TTC pour $Nombre articles est : $prixTTC €<br>";

// Affichage des types de variables
echo "Le Type de la variable  TVA : " . gettype($TVA) . "<br>";
echo "Le Type de la variable prix : " . gettype($prix) . "<br>";
echo "Le Type de la variable Nombre : " . gettype($Nombre) . "<br>";
echo "Le Type de la variable prixHT : " . gettype($prixHT) . "<br>";
echo "Le Type de la variable prixTTC : " . gettype($prixTTC) . "<br>";


?>
