<?php
//echo " le resultat du script php suivant est : ";

for($i=1;$i<7;$i++) { echo "<h$i> $i :Titre de niveau $i </h$i>"; }
?>