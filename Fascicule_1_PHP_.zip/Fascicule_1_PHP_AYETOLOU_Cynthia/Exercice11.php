<?php
$nombres = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// Afficher avec print_r

echo "<h2>Affichage avec print_r :</h2>";
echo "<pre>"; 
print_r($nombres);
echo "</pre>";

// Afficher avec for
echo "<h2>Affichage avec une boucle for :</h2>";
for ($i = 0; $i < count($nombres); $i++) {
    echo "Entier $i : " . $nombres[$i] . "<br>";
}

// Afficher  foreach
echo "<h2>Affichage avec une boucle foreach :</h2>";
foreach ($nombres as $index => $valeur) {
    echo "$valeur<br>";
}
?>
