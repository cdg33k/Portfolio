<?php
// Récupération des données du formulaire
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$adresse = $_POST['adresse'];
$ville = $_POST['ville'];
$code_postal = $_POST['code_postal'];

// Affichage des données dans un tableau HTML
echo "<h3>Informations du Client</h3>";
echo "<table border='1' style='border-collapse: collapse;'>";
echo "<tr><th>Champ</th><th>Valeur</th></tr>";
echo "<tr><td>Nom</td><td>$nom</td></tr>";
echo "<tr><td>Prénom</td><td>$prenom</td></tr>";
echo "<tr><td>Adresse</td><td>$adresse</td></tr>";
echo "<tr><td>Ville</td><td>$ville</td></tr>";
echo "<tr><td>Code Postal</td><td>$code_postal</td></tr>";
echo "</table>";
?>
