function compareNumbers(a, b, c) {
    if (a === b && b === c) {
        console.log("Les trois variables sont identiques.");
    } else if (a === b || a === c || b === c) {
        console.log("Deux des variables sont de valeurs égales.");
    } else {
        console.log("Les trois variables sont différentes.");
    }
}

// Exemple d'utilisation
let x = 5, y = 5, z = 10;
compareNumbers(x, y, z);
