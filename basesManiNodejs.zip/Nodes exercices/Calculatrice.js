// calculatrice.js

// Fonction pour effectuer l'opération
function calculer(nombre1, nombre2, operation) {
    switch (operation) {
      case "addition":
        return nombre1 + nombre2;
      case "soustraction":
        return nombre1 - nombre2;
      case "multiplication":
        return nombre1 * nombre2;
      case "division":
        if (nombre2 === 0) {
          return "Erreur : Division par zéro";
        }
        return nombre1 / nombre2;
      default:
        return "Erreur : Opération non reconnue";
    }
  }
  
  // Récupérer les paramètres depuis la ligne de commande
  const args = process.argv.slice(2); // Exclure node et le fichier exécuté
  if (args.length < 3) {
    console.error("Usage : node calculatrice.js <nombre1> <nombre2> <operation>");
    process.exit(1); // Quitter le programme avec un code d'erreur
  }
  
  // Convertir les paramètres en nombres
  const nombre1 = parseFloat(args[0]);
  const nombre2 = parseFloat(args[1]);
  const operation = args[2].toLowerCase(); // Rendre l'opération insensible à la casse
  
  // Vérifier que les nombres sont valides
  if (isNaN(nombre1) || isNaN(nombre2)) {
    console.error(
      "Erreur : Les paramètres nombre1 et nombre2 doivent être des nombres."
    );
    process.exit(1);
  }
  
  // Calculer le résultat
  const resultat = calculer(nombre1, nombre2, operation);
  
  // Afficher le résultat
  console.log("Résultat de l'opération (${operation}) : ${resultat}");