function convertBytesIfElse(shortenBytes) {
    let number = parseInt(shortenBytes);
    let letter = shortenBytes.replace(number, '').toUpperCase();
    let bytes;

    if (letter === "K") {
        bytes = number * 1024;
    } else if (letter === "M") {
        bytes = number * 1024 * 1024;
    } else if (letter === "G") {
        bytes = number * 1024 * 1024 * 1024;
    } else if (letter === "T") {
        bytes = number * 1024 * 1024 * 1024 * 1024;
    } else {
        bytes = false;
    }

    console.log(bytes);
}

// Exemple d'utilisation
convertBytesIfElse("2K");
