import OpenAI from "openai";

// Initialisation avec la clé API directement dans le code
const openai = new OpenAI({
  apiKey: "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", 
});

// Fonction principale pour générer une image
async function generateImage() {
  try {
    const image = await openai.images.generate({
      prompt: "A cute baby sea otter", // Prompt pour l'image
    });

    console.log("URL de l'image générée :", image.data[0].url);
  } catch (error) {
    console.error("Erreur lors de la génération de l'image :", error.message);
  }
}

// Appel de la fonction
generateImage();
