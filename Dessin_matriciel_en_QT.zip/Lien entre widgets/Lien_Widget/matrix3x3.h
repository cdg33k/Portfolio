/**
 * @author Cynthia AYETOLOU
 * @date 12/12/2024
 * @todo Ajouter une méthode pour inverser la matrice
 */

#ifndef MATRIX3X3_H
#define MATRIX3X3_H

#include "point2d.h"
#include <array>

/**
 * @class Matrix3x3
 * @brief Représente une matrice 3x3 pour effectuer des transformations géométriques 2D,
 *        telles que la translation, la mise à l'échelle et la rotation.
 */
class Matrix3x3 {
private:
    /**
     * @brief Matrice 3x3 représentée sous forme de tableau à deux dimensions.
     * Chaque élément est de type double.
     */
    std::array<std::array<double, 3>, 3> mat;

public:
    /**
     * @brief Constructeur par défaut qui initialise la matrice à l'identité.
     */
    Matrix3x3();

    /**
     * @brief Initialise la matrice à la matrice identité.
     */
    void setInit();

    /**
     * @brief Applique une translation à la matrice.
     * @param x Déplacement en abscisse (axe X).
     * @param y Déplacement en ordonnée (axe Y).
     */
    void setTranslation(double x, double y);

    /**
     * @brief Applique une mise à l'échelle à la matrice.
     * @param sx Facteur d'échelle en abscisse (axe X).
     * @param sy Facteur d'échelle en ordonnée (axe Y).
     */
    void setScale(double sx, double sy);

    /**
     * @brief Applique une rotation à la matrice.
     * @param rz Angle de rotation en degrés (sens anti-horaire).
     */
    void setRotate(double rz);

    /**
     * @brief Affiche la matrice dans la console.
     * Utile pour le débogage et la vérification des valeurs.
     */
    void printMatrix() const;

    /**
     * @brief Surcharge de l'opérateur * pour appliquer une matrice à un point.
     * @param point Le point à transformer.
     * @return mat Le point transformé.
     */
    Point2D operator*(const Point2D &point) const;

    /**
     * @brief Accède à un élément spécifique de la matrice.
     * @param row L'indice de la ligne (0 à 2).
     * @param col L'indice de la colonne (0 à 2).
     * @return mat La valeur de l'élément à la position spécifiée.
     */
    double get(int row, int col) const {
        return mat[row][col];
    }

    /**
     * @brief Modifie un élément spécifique de la matrice.
     * @param row L'indice de la ligne (0 à 2).
     * @param col L'indice de la colonne (0 à 2).
     * @param value La nouvelle valeur à affecter à l'élément.
     */
    void set(int row, int col, double value) {
        mat[row][col] = value;
    }

    /**
     * @brief Surcharge de l'opérateur * pour multiplier deux matrices 3x3.
     * @param other La matrice à multiplier avec la matrice actuelle.
     * @return Le résultat de la multiplication des deux matrices.
     */
    Matrix3x3 operator*(const Matrix3x3 &other) const;
};

#endif // MATRIX3X3_H
