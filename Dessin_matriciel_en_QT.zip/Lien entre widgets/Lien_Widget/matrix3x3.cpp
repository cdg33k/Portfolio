/**
 * @file matrix3x3.cpp
 * @brief Implémente les méthodes de la classe Matrix3x3 pour les transformations 2D.
 *
 * @author Cynthia AYETOLOU
 * @date 12/12/2024
 * @todo Optimiser les calculs de rotation pour de meilleures performances.
 */


#include "matrix3x3.h"
#include "point2d.h"

#include <cmath>    // Pour les fonctions cos() et sin()
#include <iostream> // Pour l'affichage avec std::cout

/**
 * @brief Constructeur par défaut.
 * Initialise la matrice avec la matrice identité.
 */
Matrix3x3::Matrix3x3() {
    setInit();
}

/**
 * @brief Initialise la matrice à la matrice identité.
 * La matrice identité est :
 * \f[
 * \begin{pmatrix} 1 & 0 & 0 \\ 0 & 1 & 0 \\ 0 & 0 & 1 \end{pmatrix}
 * \f]
 */
void Matrix3x3::setInit() {
    mat = {{{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}};
}

/**
 * @brief Configure la matrice pour une translation de (x, y).
 * @param x Déplacement en abscisse (axe X).
 * @param y Déplacement en ordonnée (axe Y).
 *
 * La matrice de translation est :
 * \f[
 * \begin{pmatrix} 1 & 0 & x \\ 0 & 1 & y \\ 0 & 0 & 1 \end{pmatrix}
 * \f]
 */
void Matrix3x3::setTranslation(double x, double y) {
    setInit();
    mat[0][2] = x;
    mat[1][2] = y;
}

/**
 * @brief Configure la matrice pour une mise à l'échelle (sx, sy).
 * @param sx Facteur d'échelle en abscisse (axe X).
 * @param sy Facteur d'échelle en ordonnée (axe Y).
 *
 * La matrice de mise à l'échelle est :
 * \f[
 * \begin{pmatrix} sx & 0 & 0 \\ 0 & sy & 0 \\ 0 & 0 & 1 \end{pmatrix}
 * \f]
 */
void Matrix3x3::setScale(double sx, double sy) {
    setInit();
    mat[0][0] = sx;
    mat[1][1] = sy;
}

/**
 * @brief Configure la matrice pour une rotation de `rz` degrés (sens anti-horaire).
 * @param rz Angle de rotation en degrés.
 *
 * La matrice de rotation est :
 * \f[
 * \begin{pmatrix} \cos(\theta) & -\sin(\theta) & 0 \\ \sin(\theta) & \cos(\theta) & 0 \\ 0 & 0 & 1 \end{pmatrix}
 * \f]
 * où \(\theta = \text{rz} \times \pi / 180\) pour convertir en radians.
 */
void Matrix3x3::setRotate(double rz) {
    setInit();
    double rad = rz * M_PI / 180.0; // Conversion en radians
    mat[0][0] = cos(rad);
    mat[0][1] = -sin(rad);
    mat[1][0] = sin(rad);
    mat[1][1] = cos(rad);
}

/**
 * @brief Affiche la matrice dans la console.
 * Utilisé pour le débogage et la vérification des valeurs.
 */
void Matrix3x3::printMatrix() const {
    std::cout << "Matrice 3x3 :\n";
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            std::cout << mat[i][j] << " ";
        }
        std::cout << "\n"; // Nouvelle ligne après chaque ligne de la matrice
    }
    std::cout << std::endl; // Ligne vide pour séparer les affichages
}

/**
 * @brief Surcharge de l'opérateur * pour appliquer la matrice à un point 2D.
 * @param point Le point à transformer.
 * @return Le point transformé.
 *
 * Le calcul effectué est :
 * \f[
 * \begin{pmatrix} x' \\ y' \end{pmatrix} = \begin{pmatrix} m_{00} & m_{01} & m_{02} \\ m_{10} & m_{11} & m_{12} \end{pmatrix} \begin{pmatrix} x \\ y \\ 1 \end{pmatrix}
 * \f]
 */
Point2D Matrix3x3::operator*(const Point2D &point) const {
    return Point2D(
        mat[0][0] * point.x + mat[0][1] * point.y + mat[0][2],
        mat[1][0] * point.x + mat[1][1] * point.y + mat[1][2]
        );
}

/**
 * @brief Surcharge de l'opérateur * pour multiplier deux matrices 3x3.
 * @param other La matrice à multiplier avec la matrice actuelle.
 * @return Le résultat de la multiplication des deux matrices.
 *
 * Le calcul effectué pour chaque élément \(r_{i,j}\) est :
 * \f[
 * r_{i,j} = \sum_{k=0}^{2} m_{i,k} \times o_{k,j}
 * \f]
 */
Matrix3x3 Matrix3x3::operator*(const Matrix3x3 &other) const { // il faut faire deux boucles imbriquees pour le produit de deux matrices
    Matrix3x3 result;
    for (int i = 0; i < 3; ++i) {  // Une boucle pour les lignes de la première matrice (i).
        for (int j = 0; j < 3; ++j) { // Une boucle pour les colonnes de la deuxième matrice (j).
            result.set(i, j, mat[i][0] * other.get(0, j) + // et la troiseime qui fait la somme est mise directement vu que j'ai deux matrice de taille fixe 3x3
                                 mat[i][1] * other.get(1, j) +
                                 mat[i][2] * other.get(2, j));
        }
    }
    return result;
}

// Pour le produit de plusieurs matrices il faut faire trois boucles imbriqueées.
//Une boucle pour les lignes de la première matrice (i).
//Une boucle pour les colonnes de la deuxième matrice (j).
//et une derniere boucle pour effectuer le produit et la somme des éléments de chaque ligne avec chaque colonne (k).
// dans notre cas la taille est fixe donc j'ai fait deux boucles et effectué la somme manuellement
