/**
 * @author Cynthia AYETOLOU
 * @date 12/12/2024
 */

#include "mainwindow.h"
#include <QApplication>

#include "matrix3x3.h"  // Inclut la classe Matrix3x3 pour les transformations
#include "point2d.h"    // Inclut la classe Point2D pour représenter des points 2D

#include <iostream>     // Pour l'affichage des tests dans la console

/**
 * @brief Fonction principale du programme Qt.
 * @param argc Nombre d'arguments en ligne de commande.
 * @param argv Tableau des arguments en ligne de commande.
 * @return Code de retour de l'application.
 */
int main(int argc, char *argv[]) {
    // Initialisation de l'application Qt
    QApplication a(argc, argv);

    // Création et affichage de la fenêtre principale
    MainWindow w;
    w.show();

    // ----- TESTS DES FONCTIONNALITÉS DE Matrix3x3 (s'affichent dans la console) -----

    Matrix3x3 matrix;        // Création d'une matrice 3x3
    Point2D point(1.0, 2.0); // Création d'un point avec les coordonnées (1.0, 2.0)

    // Initialiser la matrice à l'identité et l'afficher
    matrix.setInit();
    std::cout << "Matrice identité :\n";
    matrix.printMatrix();

    // Appliquer une translation à la matrice et l'afficher
    std::cout << "Matrice de translation (5, 3) :\n";
    matrix.setTranslation(5.0, 3.0);
    matrix.printMatrix();

    // Appliquer la translation au point et afficher le résultat
    matrix.setTranslation(5.0, 3.0);
    Point2D translatedPoint = matrix * point;
    std::cout << "Point après translation : ("
              << translatedPoint.x << ", "
              << translatedPoint.y << ")\n";

    // Appliquer une mise à l'échelle à la matrice et l'afficher
    std::cout << "Matrice de mise à l'échelle (2, 2) :\n";
    matrix.setScale(2.0, 2.0);
    matrix.printMatrix();

    // Appliquer une rotation à la matrice et l'afficher
    std::cout << "Matrice de rotation (45 degrés) :\n";
    matrix.setRotate(45.0);
    matrix.printMatrix();

    // ----- FIN DES TESTS -----


    return a.exec();
}
