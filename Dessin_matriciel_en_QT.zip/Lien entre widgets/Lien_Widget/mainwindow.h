/**
 * @author Cynthia AYETOLOU
 * @date 12/122024
 * @todo Ajouter LES METHODES POUR MODIFIER LA MATRICE
 */

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "matrix3x3.h"  // Inclure la classe Matrix3x3 pour les opérations de transformation.

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

/**
 * @class MainWindow
 * @brief La classe MainWindow gère l'interface utilisateur principale et les interactions avec le Canvas.
 */
class MainWindow : public QMainWindow {
    Q_OBJECT

private:
    Ui::MainWindow *ui; ///< Pointeur vers l'interface utilisateur générée par Qt Designer
    Matrix3x3 M;        ///< Matrice de transformation utilisée pour appliquer des opérations sur le Canvas
    Matrix3x3 M1;       ///< Matrice utilisée pour sauvegarder l'état actuel de M

public:
    /**
     * @brief Constructeur de la classe MainWindow
     * @param parent Pointeur vers le widget parent (par défaut nullptr)
     */
    explicit MainWindow(QWidget *parent = nullptr);

    /**
     * @brief Destructeur de la classe MainWindow
     */
    ~MainWindow();

private slots:
    /**
     * @brief Initialise la matrice M à la matrice identité.
     */
    void onInit();

    /**
     * @brief Applique une translation à la matrice M.
     */
    void onTranslate();

    /**
     * @brief Applique une rotation à la matrice M.
     */
    void onRotate();

    /**
     * @brief Applique une mise à l'échelle à la matrice M.
     */
    void onScale();

    /**
     * @brief Définit la forme à dessiner sur le Canvas comme une maison.
     */
    void onHouse();

    /**
     * @brief Définit la forme à dessiner sur le Canvas comme un sapin.
     */
    void onTree();

    /**
     * @brief Définit la forme à dessiner sur le Canvas comme une forme personnalisée.
     */
    void onCustom();

    /**
     * @brief Gère le clic sur le bouton "Maison" pour afficher la forme maison.
     */
    void on_btnHouse_clicked();

    /**
     * @brief Sauvegarde la matrice M dans M1.
     */
    void onSaveMtoM1();

    /**
     * @brief Multiplie la matrice M par M1 et stocke le résultat dans M.
     */
    void onMultiplyMbyM1();

    /**
     * @brief Multiplie la matrice M1 par M et stocke le résultat dans M.
     */
    void onMultiplyM1byM();
};

#endif // MAINWINDOW_H
