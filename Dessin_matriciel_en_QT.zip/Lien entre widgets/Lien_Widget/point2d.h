/**
 * @author Cynthia AYETOLOU
 * @date 12/12/2024
 * @todo Ajouter des méthodes pour calculer la distance entre deux points.
 */

#ifndef POINT2D_H
#define POINT2D_H

/**
 * @class Point2D
 * @brief Représente un point en deux dimensions avec des coordonnées x et y.
 */
class Point2D {
public:
    double x; ///< Coordonnée en abscisse (axe X).
    double y; ///< Coordonnée en ordonnée (axe Y).

    /**
     * @brief Constructeur de la classe Point2D.
     * @param x Valeur initiale pour la coordonnée x (par défaut 0.0).
     * @param y Valeur initiale pour la coordonnée y (par défaut 0.0).
     */
    Point2D(double x = 0.0, double y = 0.0);
};

#endif // POINT2D_H
