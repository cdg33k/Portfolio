/**
 * @author Cynthia AYETOLOU
 * @date 12/12/2024
 */

#include "mainwindow.h"
#include "ui_mainwindow.h"

/**
 * @brief Constructeur de la classe MainWindow.
 * Initialise les composants de l'interface utilisateur et connecte les signaux aux slots.
 * @param parent Widget parent (par défaut nullptr).
 */
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

    // Connecter les boutons d'initialisation, translation, rotation et mise à l'échelle aux slots correspondants
    connect(ui->init, &QPushButton::clicked, this, &MainWindow::onInit);
    connect(ui->translateBtn, &QPushButton::clicked, this, &MainWindow::onTranslate);
    connect(ui->rotateBtn, &QPushButton::clicked, this, &MainWindow::onRotate);
    connect(ui->scaleBtn, &QPushButton::clicked, this, &MainWindow::onScale);

    // Connexions pour synchroniser les DoubleSpinBox avec les éléments de la matrice dans Canvas
    connect(ui->doubleSpinBox, &QDoubleSpinBox::valueChanged, ui->widget, &Canvas::setMat00);
    connect(ui->doubleSpinBox_2, &QDoubleSpinBox::valueChanged, ui->widget, &Canvas::setMat01);
    connect(ui->doubleSpinBox_3, &QDoubleSpinBox::valueChanged, ui->widget, &Canvas::setMat02);
    connect(ui->doubleSpinBox_4, &QDoubleSpinBox::valueChanged, ui->widget, &Canvas::setMat10);
    connect(ui->doubleSpinBox_5, &QDoubleSpinBox::valueChanged, ui->widget, &Canvas::setMat11);
    connect(ui->doubleSpinBox_6, &QDoubleSpinBox::valueChanged, ui->widget, &Canvas::setMat12);
    connect(ui->doubleSpinBox_7, &QDoubleSpinBox::valueChanged, ui->widget, &Canvas::setMat20);
    connect(ui->doubleSpinBox_8, &QDoubleSpinBox::valueChanged, ui->widget, &Canvas::setMat21);
    connect(ui->doubleSpinBox_9, &QDoubleSpinBox::valueChanged, ui->widget, &Canvas::setMat22);

    // Connexions pour mettre à jour les DoubleSpinBox en réponse aux signaux émis par Canvas
    connect(ui->widget, &Canvas::changeMat00, ui->doubleSpinBox, &QDoubleSpinBox::setValue);
    connect(ui->widget, &Canvas::changeMat01, ui->doubleSpinBox_2, &QDoubleSpinBox::setValue);
    connect(ui->widget, &Canvas::changeMat02, ui->doubleSpinBox_3, &QDoubleSpinBox::setValue);
    connect(ui->widget, &Canvas::changeMat10, ui->doubleSpinBox_4, &QDoubleSpinBox::setValue);
    connect(ui->widget, &Canvas::changeMat11, ui->doubleSpinBox_5, &QDoubleSpinBox::setValue);
    connect(ui->widget, &Canvas::changeMat12, ui->doubleSpinBox_6, &QDoubleSpinBox::setValue);
    connect(ui->widget, &Canvas::changeMat20, ui->doubleSpinBox_7, &QDoubleSpinBox::setValue);
    connect(ui->widget, &Canvas::changeMat21, ui->doubleSpinBox_8, &QDoubleSpinBox::setValue);
    connect(ui->widget, &Canvas::changeMat22, ui->doubleSpinBox_9, &QDoubleSpinBox::setValue);

    // Connexions pour sélectionner les formes à dessiner
    connect(ui->btnHouse, &QPushButton::clicked, this, &MainWindow::onHouse);
    connect(ui->btnTree, &QPushButton::clicked, this, &MainWindow::onTree);
    connect(ui->btnCustom, &QPushButton::clicked, this, &MainWindow::onCustom);

    // Connexions pour gérer les opérations sur les matrices
    connect(ui->saveBtn, &QPushButton::clicked, this, &MainWindow::onSaveMtoM1);
    connect(ui->mxm1Btn, &QPushButton::clicked, this, &MainWindow::onMultiplyMbyM1);
    connect(ui->m1xmBtn, &QPushButton::clicked, this, &MainWindow::onMultiplyM1byM);
}

/**
 * @brief Destructeur de la classe MainWindow.
 * Libère les ressources associées à l'interface utilisateur.
 */
MainWindow::~MainWindow() {
    delete ui;
}

/**
 * @brief Réinitialise la matrice à l'identité et met à jour l'interface.
 */
void MainWindow::onInit() {
    M.setInit(); // Réinitialiser la matrice
    // Mettre à jour les valeurs des DoubleSpinBox
    ui->doubleSpinBox->setValue(M.get(0, 0));
    ui->doubleSpinBox_2->setValue(M.get(0, 1));
    ui->doubleSpinBox_3->setValue(M.get(0, 2));
    ui->doubleSpinBox_4->setValue(M.get(1, 0));
    ui->doubleSpinBox_5->setValue(M.get(1, 1));
    ui->doubleSpinBox_6->setValue(M.get(1, 2));
    ui->doubleSpinBox_7->setValue(M.get(2, 0));
    ui->doubleSpinBox_8->setValue(M.get(2, 1));
    ui->doubleSpinBox_9->setValue(M.get(2, 2));

    ui->widget->update(); // Redessiner le Canvas
}

/**
 * @brief Applique une translation à la matrice en fonction des valeurs saisies.
 */
void MainWindow::onTranslate() {
    double tx = ui->doubleSpinBox_16->value(); // Récupérer la valeur tx
    double ty = ui->doubleSpinBox_15->value(); // Récupérer la valeur ty
    M.setTranslation(tx, ty); // Appliquer la translation

    // Mettre à jour les DoubleSpinBox
    ui->doubleSpinBox->setValue(M.get(0, 0));
    ui->doubleSpinBox_2->setValue(M.get(0, 1));
    ui->doubleSpinBox_3->setValue(M.get(0, 2));
    ui->doubleSpinBox_4->setValue(M.get(1, 0));
    ui->doubleSpinBox_5->setValue(M.get(1, 1));
    ui->doubleSpinBox_6->setValue(M.get(1, 2));
    ui->doubleSpinBox_7->setValue(M.get(2, 0));
    ui->doubleSpinBox_8->setValue(M.get(2, 1));
    ui->doubleSpinBox_9->setValue(M.get(2, 2));

    ui->widget->update(); // Redessiner le Canvas
}

/**
 * @brief Applique une rotation à la matrice en fonction de l'angle saisi.
 */
void MainWindow::onRotate() {
    double rz = ui->doubleSpinBox_17->value(); // Récupérer l'angle de rotation
    M.setRotate(rz); // Appliquer la rotation

    // Mettre à jour les DoubleSpinBox
    ui->doubleSpinBox->setValue(M.get(0, 0));
    ui->doubleSpinBox_2->setValue(M.get(0, 1));
    ui->doubleSpinBox_3->setValue(M.get(0, 2));
    ui->doubleSpinBox_4->setValue(M.get(1, 0));
    ui->doubleSpinBox_5->setValue(M.get(1, 1));
    ui->doubleSpinBox_6->setValue(M.get(1, 2));
    ui->doubleSpinBox_7->setValue(M.get(2, 0));
    ui->doubleSpinBox_8->setValue(M.get(2, 1));
    ui->doubleSpinBox_9->setValue(M.get(2, 2));

    ui->widget->update(); // Redessiner le Canvas
}

/**
 * @brief Applique une mise à l'échelle à la matrice.
 */
void MainWindow::onScale() {
    double sx = ui->doubleSpinBox_18->value(); // Récupérer le facteur sx
    double sy = ui->doubleSpinBox_19->value(); // Récupérer le facteur sy
    M.setScale(sx, sy); // Appliquer la mise à l'échelle

    // Mettre à jour les DoubleSpinBox
    ui->doubleSpinBox->setValue(M.get(0, 0));
    ui->doubleSpinBox_2->setValue(M.get(0, 1));
    ui->doubleSpinBox_3->setValue(M.get(0, 2));
    ui->doubleSpinBox_4->setValue(M.get(1, 0));
    ui->doubleSpinBox_5->setValue(M.get(1, 1));
    ui->doubleSpinBox_6->setValue(M.get(1, 2));
    ui->doubleSpinBox_7->setValue(M.get(2,0));
    ui->doubleSpinBox_8->setValue(M.get(2,1));
    ui->doubleSpinBox_9->setValue(M.get(2,2));

    // Redessiner le Canvas
    ui->widget->update();
}

void MainWindow::on_btnHouse_clicked()
{

}

/**
 * @brief Définit la forme affichée sur le Canvas comme une maison.
 */
void MainWindow::onHouse() {
    ui->widget->setShape("house");
}

/**
 * @brief Définit la forme affichée sur le Canvas comme un sapin.
 */
void MainWindow::onTree() {
    ui->widget->setShape("tree");
}

/**
 * @brief Définit la forme affichée sur le Canvas comme une forme personnalisée (cube).
 */
void MainWindow::onCustom() {
    ui->widget->setShape("custom");
}

/**
 * @brief Sauvegarde la matrice `M` dans `M1`.
 */
void MainWindow::onSaveMtoM1() {
    M1 = M;
    qDebug() << "Matrice M sauvegardée dans M1.";
}

/**
 * @brief Multiplie `M` par `M1` et met à jour `M` avec le résultat.
 */
void MainWindow::onMultiplyMbyM1() {
    M = M * M1;
    ui->widget->updateMatrix(M);
    qDebug() << "Produit M x M1 effectué et stocké dans M.";
}

/**
 * @brief Multiplie `M1` par `M` et met à jour `M` avec le résultat.
 */
void MainWindow::onMultiplyM1byM() {
    M = M1 * M;
    ui->widget->updateMatrix(M);
    qDebug() << "Produit M1 x M effectué et stocké dans M.";
}

