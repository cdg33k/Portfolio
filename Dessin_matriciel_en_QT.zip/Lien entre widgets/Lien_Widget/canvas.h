/**
 * @author Cynthia AYETOLOU
 * @date 12/12/2024
 * @todo Implémenter le support de formes supplémentaires.
 */

#ifndef CANVAS_H
#define CANVAS_H

#include <QWidget>
#include <QPainter>
#include <QBrush>
#include <QPen>
#include <QVector>
#include "matrix3x3.h" // Inclure la classe Matrix3x3 pour les transformations
#include "point2d.h"   // Inclure la classe Point2D pour représenter les points 2D

/**
 * @class Canvas
 * @brief Widget pour afficher et transformer des formes géométriques.
 * La classe Canvas représente une zone de dessin où des formes géométriques peuvent être affichées
 *        et transformées via des opérations matricielles.
 */
class Canvas : public QWidget {
    Q_OBJECT

private:
    Matrix3x3 M;                   ///< Matrice de transformation appliquée aux objets
    QVector<Point2D> maison;       ///< Vecteur de points représentant la forme à dessiner (ex. : une maison)

public:
    /**
     * @brief Constructeur de la classe Canvas
     * @param parent Pointeur vers le widget parent (par défaut nullptr)
     */
    explicit Canvas(QWidget *parent = nullptr);

    /**
     * @brief Met à jour la matrice de transformation avec une nouvelle matrice
     * @param newMatrix La nouvelle matrice de transformation
     */
    void updateMatrix(const Matrix3x3 &newMatrix);

    /**
     * @brief Définit la forme à dessiner (par exemple, maison, sapin, cube)
     * @param shapeName Le nom de la forme à dessiner
     */
    void setShape(const QString &shapeName);

protected:
    /**
     * @brief Événement de dessin pour redessiner le Canvas
     * @param event Pointeur vers l'événement de dessin
     */
    void paintEvent(QPaintEvent *event) override;

public slots:
    // Slots pour modifier individuellement les éléments de la matrice de transformation
    void setMat00(double value);
    void setMat01(double value);
    void setMat02(double value);
    void setMat10(double value);
    void setMat11(double value);
    void setMat12(double value);
    void setMat20(double value);
    void setMat21(double value);
    void setMat22(double value);

signals:
    // Signaux émis lorsqu'un élément de la matrice est modifié
    void changeMat00(double value);
    void changeMat01(double value);
    void changeMat02(double value);
    void changeMat10(double value);
    void changeMat11(double value);
    void changeMat12(double value);
    void changeMat20(double value);
    void changeMat21(double value);
    void changeMat22(double value);

    /**
     * @brief Signal émis lorsqu'une mise à jour générale de la matrice a lieu
     */
    void matrixUpdated();
};

#endif // CANVAS_H
