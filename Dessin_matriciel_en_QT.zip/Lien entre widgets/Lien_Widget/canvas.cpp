/**
 * @author Cynthia AYETOLOU
 * @date 12/12/2024
 */

#include "canvas.h"

/**
 * @brief Constructeur de la classe Canvas.
 * Initialise la matrice avec l'identité et définit les points de la forme "maison".
 * @param parent Widget parent (par défaut nullptr).
 */
Canvas::Canvas(QWidget *parent)
    : QWidget(parent) {
    // Initialiser la matrice avec la matrice identité
    M.setInit();

    // Initialiser l'objet maison avec des points représentant une maison simple
    maison = {
        Point2D(-0.3, 0.1),
        Point2D(-0.3, -0.3),
        Point2D(0.3, -0.3),
        Point2D(0.3, 0.1),
        Point2D(-0.3, 0.1),
        Point2D(0, 0.3),
        Point2D(0.3, 0.1)
    };
}

/**
 * @brief Méthode de dessin appelée automatiquement pour redessiner le widget.
 */
void Canvas::paintEvent(QPaintEvent *) {
    const int w = width(), h = height();

    // Mettre à l'échelle les points de la maison en fonction de la taille du widget
    QVector<Point2D> scaledMaison;
    for (const Point2D &p : maison) {
        scaledMaison.append(Point2D(p.x * w, p.y * h));
    }

    QPainter painter(this);

    // Remplir l'arrière-plan en blanc
    QBrush whiteBrush(Qt::SolidPattern);
    whiteBrush.setColor(Qt::white);
    painter.fillRect(0, 0, width(), height(), whiteBrush);

    // Dessiner les axes en rouge
    QPointF points[7] = {{0, -2}, {80, -2}, {80, -10}, {100, 0}, {80, 10}, {80, 2}, {0, 2}};
    painter.save();
    painter.translate(width() / 2, height() / 2); // Centrer les axes

    painter.save();
    painter.setPen(Qt::NoPen);
    painter.setBrush(Qt::red);
    painter.drawPolygon(points, 7);

    // Tourner et dessiner un autre axe en vert (rotation de 90 degrés)
    painter.save();
    painter.setBrush(Qt::green);
    painter.rotate(90);
    painter.drawPolygon(points, 7);
    painter.restore();
    painter.restore();

    // Dessiner la maison d'origine en pointillés bleus
    painter.setPen(QPen(Qt::blue, 3, Qt::DotLine));
    for (int i = 0; i < scaledMaison.count() - 1; i++) {
        painter.drawLine(scaledMaison[i].x / 2, scaledMaison[i].y / 2,
                         scaledMaison[i + 1].x / 2, scaledMaison[i + 1].y / 2);
    }

    // Appliquer la transformation à la maison et dessiner en traits pleins
    painter.setPen(QPen(Qt::darkCyan, 3));
    Point2D P0, P1;
    for (int i = 0; i < maison.count() - 1; i++) {
        P0 = M * maison[i]; // Appliquer la transformation aux points d'origine
        P1 = M * maison[i + 1];
        painter.drawLine(P0.x * w / 2, P0.y * h / 2,
                         P1.x * w / 2, P1.y * h / 2);
    }

    painter.restore();
}

/**
 * @brief Met à jour la matrice de transformation avec une nouvelle matrice.
 * @param newMatrix La nouvelle matrice de transformation.
 */
void Canvas::updateMatrix(const Matrix3x3 &newMatrix) {
    M = newMatrix;

    // Émettre des signaux pour chaque élément de la matrice
    emit changeMat00(M.get(0, 0));
    emit changeMat01(M.get(0, 1));
    emit changeMat02(M.get(0, 2));
    emit changeMat10(M.get(1, 0));
    emit changeMat11(M.get(1, 1));
    emit changeMat12(M.get(1, 2));
    emit changeMat20(M.get(2, 0));
    emit changeMat21(M.get(2, 1));
    emit changeMat22(M.get(2, 2));

    // Redessiner le Canvas après mise à jour
    update();
}

// Définir chaque élément de la matrice et émettre les signaux correspondants
void Canvas::setMat00(double value) {
    M.set(0, 0, value);
    emit changeMat00(value);
    update();
}

void Canvas::setMat01(double value) {
    M.set(0, 1, value);
    emit changeMat01(value);
    update();
}

void Canvas::setMat02(double value) {
    M.set(0, 2, value);
    emit changeMat02(value);
    update();
}

void Canvas::setMat10(double value) {
    M.set(1, 0, value);
    emit changeMat10(value);
    update();
}

void Canvas::setMat11(double value) {
    M.set(1, 1, value);
    emit changeMat11(value);
    update();
}

void Canvas::setMat12(double value) {
    M.set(1, 2, value);
    emit changeMat12(value);
    update();
}

void Canvas::setMat20(double value) {
    M.set(2, 0, value);
    emit changeMat20(value);
    update();
}

void Canvas::setMat21(double value) {
    M.set(2, 1, value);
    emit changeMat21(value);
    update();
}

void Canvas::setMat22(double value) {
    M.set(2, 2, value);
    emit changeMat22(value);
    update();
}

/**
 * @brief Définit la forme à dessiner sur le Canvas.
 * @param shapeName Le nom de la forme ("house", "tree", ou "custom").
 */
void Canvas::setShape(const QString &shapeName) {
    if (shapeName == "house") {
        // Définir les points pour une maison simple
        maison = {
            Point2D(-0.3, 0.1), Point2D(-0.3, -0.3), Point2D(0.3, -0.3),
            Point2D(0.3, 0.1), Point2D(-0.3, 0.1), Point2D(0, 0.3),
            Point2D(0.3, 0.1)
        };
    } else if (shapeName == "tree") {
        // Définir les points pour un sapin simple
        maison = {
            // Tronc
            Point2D(-0.05, -0.3), Point2D(0.05, -0.3),
            Point2D(0.05, -0.5), Point2D(-0.05, -0.5),
            Point2D(-0.05, -0.3),

            // Branches
            Point2D(-0.2, -0.3), Point2D(0.0, -0.1), Point2D(0.2, -0.3),
            Point2D(-0.15, -0.1), Point2D(0.0, 0.1), Point2D(0.15, -0.1),
            Point2D(-0.1, 0.1), Point2D(0.0, 0.3), Point2D(0.1, 0.1)
        };
    } else if (shapeName == "custom") {
        // Définir les points pour un cube simple
        maison = {
            // Face avant
            Point2D(-0.2, -0.2), Point2D(0.2, -0.2),
            Point2D(0.2, 0.2), Point2D(-0.2, 0.2),

            // Face arrière
            Point2D(-0.1, -0.1), Point2D(0.3, -0.1),
            Point2D(0.3, 0.3), Point2D(-0.1, 0.3),

            // Arêtes reliant les faces avant et arrière
            Point2D(-0.2, -0.2), Point2D(-0.1, -0.1),
            Point2D(0.2, -0.2), Point2D(0.3, -0.1),
            Point2D(0.2, 0.2), Point2D(0.3, 0.3),
            Point2D(-0.2, 0.2), Point2D(-0.1, 0.3)
        };
    }

    // Redessiner le Canvas après avoir changé la forme
    update();
}
