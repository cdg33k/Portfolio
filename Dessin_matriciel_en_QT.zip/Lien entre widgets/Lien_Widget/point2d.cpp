/**
 * @brief Constructeur de la classe Point2D.
 * Initialise les coordonnées x et y avec les valeurs spécifiées.
 *
 * @author Cynthia AYETOLOU
 * @date 12/12/2024
 * @todo Implémenter une méthode pour afficher les coordonnées du point.
 */

#include "point2d.h"

/**
 * @brief Constructeur de la classe Point2D.
 * Initialise les coordonnées x et y avec les valeurs spécifiées.
 * @param x Coordonnée en abscisse (par défaut 0.0).
 * @param y Coordonnée en ordonnée (par défaut 0.0).
 */
Point2D::Point2D(double x, double y) : x(x), y(y) {}
